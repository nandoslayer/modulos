#!/bin/bash

nome_usuario=$1
senha=$2
dias=$3
limite_sessoes=$4

if [ ! -f /root/usuarios.db ]; then
  touch /root/usuarios.db
fi

sudo bash /opt/apipainel/RemoveUser.sh $nome_usuario

data_expiracao=$(date "+%Y-%m-%d" -d "+$dias days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")

useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" > /etc/SSHPlus/senha/$nome_usuario

echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

echo "sucesso"