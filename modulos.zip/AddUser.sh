#!/bin/bash

nome_usuario="$1"
senha="$2"
dias="$3"
limite_sessoes="$4"

db="/root/usuarios.db"
senha_dir="/etc/SSHPlus/senha"

# Garante existência dos arquivos e diretórios, com permissão 777
if ! sudo test -f "$db"; then
    sudo touch "$db"
fi
sudo chmod 777 "$db"

sudo mkdir -p "$senha_dir"
sudo chmod 777 "$senha_dir"

# Remove o usuário antigo (silencioso)
sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

# Cria o usuário com senha e expiração
data_expiracao=$(date "+%Y-%m-%d" -d "+$dias days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")
sudo useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

# Salva senha e permissões
echo "$senha" | sudo tee "$senha_dir/$nome_usuario" >/dev/null
sudo chmod 777 "$senha_dir/$nome_usuario"

# Registra no DB
echo "$nome_usuario $limite_sessoes" | sudo tee -a "$db" >/dev/null

echo "sucesso"
