#!/bin/bash

nome_usuario="$1"
senha="$2"
dias="$3"
limite_sessoes="$4"

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db

bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

# 🔎 Pega o próximo UID livre (a partir de 1000)
get_next_uid() {
    awk -F: '$3 >= 1000 { print $3 }' /etc/passwd | sort -n | awk 'END { print $1 + 1 }'
}
proximo_uid=$(get_next_uid)

senha_criptografada=$(openssl passwd -1 "$senha")
data_expira=$(date -d "+$dias days" +%Y-%m-%d)

# 🔐 Cria o usuário com UID livre
useradd -M -s /bin/false -u "$proximo_uid" -p "$senha_criptografada" -e "$data_expira" "$nome_usuario" >/dev/null 2>&1

# Salva senha e limite
mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" > "/etc/SSHPlus/senha/$nome_usuario"

echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

echo "sucesso"
