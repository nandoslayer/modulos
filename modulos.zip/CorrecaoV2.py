#!/usr/bin/env python3
import os
import subprocess
import shutil
import re
import json

def print_info(msg):
    print(f"\033[1;34m[INFO]\033[0m {msg}")

def print_ok(msg):
    print(f"\033[1;32m[OK]\033[0m {msg}")

def print_warn(msg):
    print(f"\033[1;33m[ATENÇÃO]\033[0m {msg}")

def print_fail(msg):
    print(f"\033[1;31m[ERRO]\033[0m {msg}")

def normalize_sshd_config():
    print_info("Normalizando sshd_config...")
    sshd_conf = "/etc/ssh/sshd_config"
    sshd_backup = "/etc/ssh/sshd_config.bkp"
    if not os.path.isfile(sshd_backup):
        shutil.copy2(sshd_conf, sshd_backup)
        print_ok(f"Backup do sshd_config: {sshd_backup}")
    desired_entries = {
        "Protocol":               "Protocol 2",
        "PermitRootLogin":        "PermitRootLogin yes",
        "PasswordAuthentication": "PasswordAuthentication yes",
        "ChallengeResponseAuthentication": "ChallengeResponseAuthentication no",
        "PermitTunnel":           "PermitTunnel yes",
        "UsePAM":                 "UsePAM yes",
        "ClientAliveInterval":    "ClientAliveInterval 60",
        "ClientAliveCountMax":    "ClientAliveCountMax 3",
        "MaxAuthTries":           "MaxAuthTries 3",
        "Compression":            "Compression no",
        "UseDNS":                 "UseDNS no",
        "MaxSessions":            "MaxSessions 100"
    }
    if not os.path.isfile(sshd_conf):
        print_fail("Arquivo sshd_config não encontrado!")
        return
    with open(sshd_conf, "r") as f:
        lines = f.readlines()
    keys_pattern = re.compile(r"^\s*(" + "|".join(desired_entries.keys()) + r")\b")
    filtered = [line for line in lines if not keys_pattern.match(line)]
    while filtered and filtered and filtered[-1].strip() == "":
        filtered.pop()
    filtered.append("\n")
    for entry in desired_entries.values():
        filtered.append(entry + "\n")
    with open(sshd_conf, "w") as f:
        f.writelines(filtered)
    subprocess.run(
        ["systemctl", "restart", "ssh"],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    print_ok("Configuração do SSH normalizada.")

def configure_iptables():
    print_info("Configurando firewall/iptables...")
    portas = [22, 81, 80, 443, 8799, 8080, 1194]
    for porta in portas:
        while True:
            rm = subprocess.run(
                f"iptables -D INPUT -p tcp --dport {porta} -j ACCEPT 2>/dev/null",
                shell=True
            )
            if rm.returncode != 0:
                break
        regra_existente = subprocess.run(
            f"iptables -C INPUT -p tcp --dport {porta} -j ACCEPT",
            shell=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        if regra_existente.returncode != 0:
            subprocess.run(
                f"iptables -A INPUT -p tcp --dport {porta} -j ACCEPT > /dev/null 2>&1",
                shell=True
            )
    print_ok("Firewall/iptables configurado.")

def configure_v2ray_xray_logs():
    v2ray_config_path = '/etc/v2ray/config.json'
    xray_config_path  = '/usr/local/etc/xray/config.json'
    log_dir           = '/var/log/v2ray'
    access_log_path   = os.path.join(log_dir, 'access.log')
    error_log_path    = os.path.join(log_dir, 'error.log')
    print_info("Preparando logs do V2Ray/Xray...")
    os.makedirs(log_dir, exist_ok=True)
    open(access_log_path, "a").close()
    open(error_log_path, "a").close()
    os.chmod(access_log_path, 0o777)
    os.chmod(error_log_path, 0o777)
    print_ok("Logs prontos.")
    def patch_v2ray_log(config_path):
        if not os.path.exists(config_path):
            print_warn(f"Arquivo não encontrado: {config_path}")
            return False
        with open(config_path, 'r') as f:
            config = json.load(f)
        config['log'] = {
            'access':   access_log_path,
            'error':    error_log_path,
            'loglevel': 'info'
        }
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        os.chmod(config_path, 0o777)
        print_ok(f"Log do V2Ray configurado.")
        return True
    def patch_xray_log(config_path):
        if not os.path.exists(config_path):
            print_warn(f"Arquivo não encontrado: {config_path}")
            return False
        with open(config_path, 'r') as f:
            config = json.load(f)
        config['log'] = {
            'access':      access_log_path,
            'dnsLog':      False,
            'error':       error_log_path,
            'loglevel':    'warning',
            'maskAddress': ''
        }
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        os.chmod(config_path, 0o777)
        print_ok(f"Log do Xray configurado.")
        return True
    v2ray_ok = patch_v2ray_log(v2ray_config_path)
    xray_ok  = patch_xray_log(xray_config_path)
    services = {
        "v2ray": v2ray_config_path,
        "xray":  xray_config_path,
    }
    print_info("Reiniciando V2Ray/Xray...")
    for servico, cfg_path in services.items():
        if servico == "v2ray" and not v2ray_ok:
            continue
        if servico == "xray" and not xray_ok:
            continue
        try:
            is_active = (subprocess.run(
                ["systemctl", "is-active", "--quiet", servico],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode == 0)
            if is_active:
                subprocess.run(
                    ["systemctl", "restart", servico],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                print_ok(f"{servico} reiniciado.")
            else:
                if os.path.exists(cfg_path):
                    subprocess.run(
                        ["systemctl", "start", servico],
                        check=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                    print_ok(f"{servico} iniciado.")
        except Exception as e:
            print_fail(f"Falha ao reiniciar/iniciar: {servico}: {e}")
    print_ok("Tudo pronto!\n")

def main():
    print_info("Configurando VPS (SSH + firewall + V2Ray/Xray)...")
    normalize_sshd_config()
    configure_iptables()
    print_ok("SSH e firewall configurados!")
    configure_v2ray_xray_logs()

if __name__ == "__main__":
    main()
