import json
import os
import subprocess

v2ray_config_path = '/etc/v2ray/config.json'
xray_config_path  = '/usr/local/etc/xray/config.json'
log_dir           = '/var/log/v2ray'
access_log_path   = os.path.join(log_dir, 'access.log')
error_log_path    = os.path.join(log_dir, 'error.log')

# Cria pasta e arquivos de log
os.makedirs(log_dir, exist_ok=True)
open(access_log_path, 'a').close()
open(error_log_path, 'a').close()

# Deixa tudo 777
os.chmod(access_log_path, 0o777)
os.chmod(error_log_path, 0o777)

def patch_v2ray_log(config_path):
    if not os.path.exists(config_path):
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)

    config['log'] = {
        'access':   access_log_path,
        'error':    error_log_path,
        'loglevel': 'info'
    }

    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    os.chmod(config_path, 0o777)
    return True

def patch_xray_log(config_path):
    if not os.path.exists(config_path):
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)

    config['log'] = {
        'access':      access_log_path,
        'dnsLog':      False,
        'error':       error_log_path,
        'loglevel':    'warning',
        'maskAddress': ''
    }

    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    os.chmod(config_path, 0o777)
    return True

v2ray_ok = patch_v2ray_log(v2ray_config_path)
xray_ok  = patch_xray_log(xray_config_path)

# Reinicia ou inicia serviços conforme estado e existência do JSON
services = {
    "v2ray": v2ray_config_path,
    "xray":  xray_config_path,
}

for servico, cfg_path in services.items():
    if servico == "v2ray" and not v2ray_ok:
        continue
    if servico == "xray"  and not xray_ok:
        continue

    try:
        is_active = (subprocess.run(
            ["systemctl", "is-active", "--quiet", servico]
        ).returncode == 0)

        if is_active:
            subprocess.run(["systemctl", "restart", servico], check=True)
            print(f"{servico} reiniciado")
        else:
            if os.path.exists(cfg_path):
                subprocess.run(["systemctl", "start", servico], check=True)
                print(f"{servico} iniciado (config encontrado)")
            else:
                print(f"{servico} não iniciado: config não encontrado em {cfg_path}")
    except Exception as e:
        print(f"Erro ao controlar {servico}: {e}")
