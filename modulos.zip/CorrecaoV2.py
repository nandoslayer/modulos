#!/usr/bin/env python3
import os
import json
import subprocess

# Caminhos de configuração e log
v2ray_config_path = '/etc/v2ray/config.json'
xray_config_path  = '/usr/local/etc/xray/config.json'
log_dir           = '/var/log/v2ray'
access_log_path   = os.path.join(log_dir, 'access.log')
error_log_path    = os.path.join(log_dir, 'error.log')

def print_info(msg):
    print(f"[INFO] {msg}")

def print_ok(msg):
    print(f"[OK] {msg}")

def print_warn(msg):
    print(f"[ATENÇÃO] {msg}")

def print_fail(msg):
    print(f"[ERRO] {msg}")

print_info("Preparando diretórios e logs do V2Ray/Xray...")
os.makedirs(log_dir, exist_ok=True)
open(access_log_path, "a").close()
open(error_log_path, "a").close()
os.chmod(access_log_path, 0o777)
os.chmod(error_log_path, 0o777)
print_ok("Logs do V2Ray/Xray preparados.\n")

def patch_v2ray_log(config_path):
    if not os.path.exists(config_path):
        print_warn(f"Arquivo de configuração não encontrado: {config_path}")
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)
    config['log'] = {
        'access':   access_log_path,
        'error':    error_log_path,
        'loglevel': 'info'
    }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    os.chmod(config_path, 0o777)
    print_ok(f"Log do V2Ray configurado: {config_path}")
    return True

def patch_xray_log(config_path):
    if not os.path.exists(config_path):
        print_warn(f"Arquivo de configuração não encontrado: {config_path}")
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)
    config['log'] = {
        'access':      access_log_path,
        'dnsLog':      False,
        'error':       error_log_path,
        'loglevel':    'warning',
        'maskAddress': ''
    }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    os.chmod(config_path, 0o777)
    print_ok(f"Log do Xray configurado: {config_path}")
    return True

print_info("Ajustando configurações do V2Ray e Xray...")
v2ray_ok = patch_v2ray_log(v2ray_config_path)
xray_ok  = patch_xray_log(xray_config_path)

services = {
    "v2ray": v2ray_config_path,
    "xray":  xray_config_path,
}

print_info("Reiniciando/iniciando serviços do V2Ray/Xray (se existirem)...")
for servico, cfg_path in services.items():
    if servico == "v2ray" and not v2ray_ok:
        continue
    if servico == "xray" and not xray_ok:
        continue
    try:
        is_active = (subprocess.run(
            ["systemctl", "is-active", "--quiet", servico],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        ).returncode == 0)
        if is_active:
            subprocess.run(
                ["systemctl", "restart", servico],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            print_ok(f"Serviço {servico} reiniciado.")
        else:
            if os.path.exists(cfg_path):
                subprocess.run(
                    ["systemctl", "start", servico],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                print_ok(f"Serviço {servico} iniciado.")
    except Exception as e:
        print_fail(f"Falha ao reiniciar/iniciar o serviço {servico}: {e}")

print_ok("\nProcesso concluído!\n")
