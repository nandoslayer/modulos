#!/usr/bin/env python3
import os
import subprocess
import shutil
import time
import glob
import re
import json

def print_info(msg):
    print(f"[INFO] {msg}")

def print_ok(msg):
    print(f"[OK] {msg}")

def print_warn(msg):
    print(f"[ATENÇÃO] {msg}")

def print_fail(msg):
    print(f"[ERRO] {msg}")

def get_distro_id():
    distro_id = ""
    if os.path.isfile("/etc/os-release"):
        with open("/etc/os-release", "r") as f:
            for line in f:
                if line.startswith("ID="):
                    distro_id = line.strip().split("=")[1].strip('"').lower()
                    break
    return distro_id

DISTRO_ID = get_distro_id()

DNS_LIST = ["1.1.1.1", "8.8.8.8"]

def configure_dns_ubuntu():
    print_info("Configurando DNS para Ubuntu...")
    override_dir = "/etc/systemd/resolved.conf.d"
    override_file = os.path.join(override_dir, "override-dns.conf")
    os.makedirs(override_dir, exist_ok=True)

    if os.path.isfile(override_file):
        ts = time.strftime("%Y%m%d%H%M%S")
        backup_file = f"{override_file}.bak-{ts}"
        shutil.copy2(override_file, backup_file)
        print_ok(f"Backup do DNS salvo: {backup_file}")

        backups = sorted(glob.glob(f"{override_file}.bak-*"), reverse=True)
        for old in backups[5:]:
            try:
                os.remove(old)
                print_info(f"Backup antigo removido: {old}")
            except:
                pass

    with open(override_file, "w") as f:
        f.write("[Resolve]\n")
        f.write(f"DNS={' '.join(DNS_LIST)}\n")
    print_ok("Arquivo de DNS criado.")

    subprocess.run([
        "systemctl", "restart", "systemd-resolved"
    ], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print_ok("systemd-resolved reiniciado.")

def configure_dns_debian():
    print_info("Configurando DNS para Debian...")
    dns_lines = "\n".join(f"nameserver {d}" for d in DNS_LIST) + "\n"

    if shutil.which("resolvconf"):
        base_file = "/etc/resolvconf/resolv.conf.d/base"
        if os.path.isfile(base_file):
            ts = time.strftime("%Y%m%d%H%M%S")
            backup_file = f"{base_file}.bak-{ts}"
            shutil.copy2(base_file, backup_file)
            print_ok(f"Backup do DNS salvo: {backup_file}")

            backups = sorted(glob.glob(f"{base_file}.bak-*"), reverse=True)
            for old in backups[5:]:
                try:
                    os.remove(old)
                    print_info(f"Backup antigo removido: {old}")
                except:
                    pass

        with open(base_file, "w") as f:
            f.write(dns_lines)

        subprocess.run(["resolvconf", "-u"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["chattr", "+i", "/etc/resolv.conf"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print_ok("DNS atualizado com resolvconf.")
    else:
        resolv_file = "/etc/resolv.conf"
        if os.path.isfile(resolv_file):
            ts = time.strftime("%Y%m%d%H%M%S")
            backup_file = f"{resolv_file}.bak-{ts}"
            shutil.copy2(resolv_file, backup_file)
            print_ok(f"Backup do DNS salvo: {backup_file}")

            backups = sorted(glob.glob(f"{resolv_file}.bak-*"), reverse=True)
            for old in backups[5:]:
                try:
                    os.remove(old)
                    print_info(f"Backup antigo removido: {old}")
                except:
                    pass

        subprocess.run(["chattr", "-i", resolv_file], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        with open(resolv_file, "w") as f:
            f.write(dns_lines)

        subprocess.run(["chattr", "+i", resolv_file], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print_ok("DNS atualizado diretamente no /etc/resolv.conf.")

def configure_dns():
    if DISTRO_ID == "ubuntu":
        configure_dns_ubuntu()
    elif DISTRO_ID == "debian":
        configure_dns_debian()

print_info(f"Detectada distro: {DISTRO_ID}")
print_info("Iniciando configuração de DNS...")
configure_dns()
print_ok("Configuração de DNS concluída.\n")

comandos = [
    "iptables -F",
    "DEBIAN_FRONTEND=noninteractive apt-get update -y -qq",
    "bash -c \"[[ $(grep -c \\\"prohibit-password\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/prohibit-password/yes/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"without-password\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/without-password/yes/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#PermitRootLogin\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#PermitRootLogin/PermitRootLogin/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^PasswordAuthentication\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#PasswordAuthentication no\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"PasswordAuthentication no\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^X11Forwarding\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'X11Forwarding no' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#X11Forwarding yes\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#X11Forwarding yes/X11Forwarding no/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"X11Forwarding yes\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/X11Forwarding yes/X11Forwarding no/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^ClientAliveInterval\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'ClientAliveInterval 60' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#ClientAliveInterval 0\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#ClientAliveInterval 0/ClientAliveInterval 60/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"ClientAliveInterval 0\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/ClientAliveInterval 0/ClientAliveInterval 60/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^ClientAliveCountMax\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'ClientAliveCountMax 3' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#ClientAliveCountMax 3\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#ClientAliveCountMax 3/ClientAliveCountMax 3/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"ClientAliveCountMax 3\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/ClientAliveCountMax 3/ClientAliveCountMax 3/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^MaxStartups\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'MaxStartups 5000:10:5000' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#MaxStartups 10:30:100\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#MaxStartups 10:30:100/MaxStartups 5000:10:5000/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"MaxStartups 5000:10:5000\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/MaxStartups 5000:10:5000/MaxStartups 5000:10:5000/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^MaxAuthTries\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'MaxAuthTries 3' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#MaxAuthTries 3\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#MaxAuthTries 3/MaxAuthTries 3/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"MaxAuthTries 3\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/MaxAuthTries 3/MaxAuthTries 3/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^Compression\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'Compression no' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#Compression no\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#Compression no/Compression no/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"Compression no\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/Compression no/Compression no/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"^UseDNS\\\" /etc/ssh/sshd_config) = '0' ]] && echo 'UseDNS no' >> /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"#UseDNS no\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/#UseDNS no/UseDNS no/g' /etc/ssh/sshd_config\"",
    "bash -c \"[[ $(grep -c \\\"UseDNS no\\\" /etc/ssh/sshd_config) != '0' ]] && sed -i 's/UseDNS no/UseDNS no/g' /etc/ssh/sshd_config\"",
    "sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config.d/60-cloudimg-settings.conf",
    "systemctl restart ssh >/dev/null 2>&1",
    "iptables -F",
    "iptables -A INPUT -p tcp --dport 81   -j ACCEPT",
    "iptables -A INPUT -p tcp --dport 80   -j ACCEPT",
    "iptables -A INPUT -p tcp --dport 443  -j ACCEPT",
    "iptables -A INPUT -p tcp --dport 8799 -j ACCEPT",
    "iptables -A INPUT -p tcp --dport 8080 -j ACCEPT",
    "iptables -A INPUT -p tcp --dport 1194 -j ACCEPT"
]

print_info("Configurando SSH e firewall...")
for cmd in comandos:
    try:
        subprocess.run(
            cmd,
            shell=True,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except subprocess.CalledProcessError:
        print_warn(f"Comando falhou (ignorado): {cmd}")
print_ok("SSH e firewall configurados.\n")

def normalize_sshd_config():
    print_info("Normalizando sshd_config...")
    sshd_conf = "/etc/ssh/sshd_config"
    desired_entries = {
        "Protocol":               "Protocol 2",
        "PermitRootLogin":        "PermitRootLogin yes",
        "PasswordAuthentication": "PasswordAuthentication yes",
        "PermitTunnel":           "PermitTunnel yes",
        "TCPKeepAlive":           "TCPKeepAlive yes",
        "UsePAM":                 "UsePAM yes",
        "X11Forwarding":          "X11Forwarding no",
        "ClientAliveInterval":    "ClientAliveInterval 60",
        "ClientAliveCountMax":    "ClientAliveCountMax 3",
        "MaxStartups":            "MaxStartups 5000:10:5000",
        "MaxAuthTries":           "MaxAuthTries 3",
        "Compression":            "Compression no",
        "UseDNS":                 "UseDNS no"
    }

    if not os.path.isfile(sshd_conf):
        print_fail("Arquivo sshd_config não encontrado!")
        return

    with open(sshd_conf, "r") as f:
        lines = f.readlines()

    keys_pattern = re.compile(r"^\s*(" + "|".join(desired_entries.keys()) + r")\b")

    filtered = [line for line in lines if not keys_pattern.match(line)]
    while filtered and filtered[-1].strip() == "":
        filtered.pop()
    filtered.append("\n")
    for entry in desired_entries.values():
        filtered.append(entry + "\n")

    with open(sshd_conf, "w") as f:
        f.writelines(filtered)

    subprocess.run(
        ["systemctl", "restart", "ssh"],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    print_ok("Configuração do SSH normalizada.")

normalize_sshd_config()
print_ok("Normalização do SSH finalizada.\n")

v2ray_config_path = '/etc/v2ray/config.json'
xray_config_path  = '/usr/local/etc/xray/config.json'
log_dir           = '/var/log/v2ray'
access_log_path   = os.path.join(log_dir, 'access.log')
error_log_path    = os.path.join(log_dir, 'error.log')

print_info("Preparando diretórios e logs do V2Ray/Xray...")
os.makedirs(log_dir, exist_ok=True)
open(access_log_path, "a").close()
open(error_log_path, "a").close()
os.chmod(access_log_path, 0o777)
os.chmod(error_log_path, 0o777)
print_ok("Logs do V2Ray/Xray preparados.\n")

def patch_v2ray_log(config_path):
    if not os.path.exists(config_path):
        print_warn(f"Arquivo de configuração não encontrado: {config_path}")
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)
    config['log'] = {
        'access':   access_log_path,
        'error':    error_log_path,
        'loglevel': 'info'
    }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    os.chmod(config_path, 0o777)
    print_ok(f"Log do V2Ray configurado: {config_path}")
    return True

def patch_xray_log(config_path):
    if not os.path.exists(config_path):
        print_warn(f"Arquivo de configuração não encontrado: {config_path}")
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)
    config['log'] = {
        'access':      access_log_path,
        'dnsLog':      False,
        'error':       error_log_path,
        'loglevel':    'warning',
        'maskAddress': ''
    }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    os.chmod(config_path, 0o777)
    print_ok(f"Log do Xray configurado: {config_path}")
    return True

print_info("Ajustando configurações do V2Ray e Xray...")
v2ray_ok = patch_v2ray_log(v2ray_config_path)
xray_ok  = patch_xray_log(xray_config_path)

services = {
    "v2ray": v2ray_config_path,
    "xray":  xray_config_path,
}

print_info("Reiniciando/iniciando serviços do V2Ray/Xray (se existirem)...")
for servico, cfg_path in services.items():
    if servico == "v2ray" and not v2ray_ok:
        continue
    if servico == "xray" and not xray_ok:
        continue
    try:
        is_active = (subprocess.run(
            ["systemctl", "is-active", "--quiet", servico],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        ).returncode == 0)
        if is_active:
            subprocess.run(
                ["systemctl", "restart", servico],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            print_ok(f"Serviço {servico} reiniciado.")
        else:
            if os.path.exists(cfg_path):
                subprocess.run(
                    ["systemctl", "start", servico],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                print_ok(f"Serviço {servico} iniciado.")
    except Exception as e:
        print_fail(f"Falha ao reiniciar/iniciar o serviço {servico}: {e}")

print_ok("\nProcesso concluído!\n")
