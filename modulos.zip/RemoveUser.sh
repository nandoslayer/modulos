#!/bin/bash

nome_usuario="$1"

if [ "$nome_usuario" = "root" ]; then
    echo "erro"
    exit 1
fi

pkill -u "$nome_usuario" >/dev/null 2>&1

userdel -f "$nome_usuario" >/dev/null 2>&1

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db
grep -v "^$nome_usuario[[:space:]]" /root/usuarios.db > /tmp/temp_db && mv /tmp/temp_db /root/usuarios.db

rm -f /etc/SSHPlus/senha/"$nome_usuario" >/dev/null 2>&1
rm -f /etc/usuarios/"$nome_usuario" >/dev/null 2>&1
rm -f /etc/TesteAtlas/"$nome_usuario.sh" >/dev/null 2>&1

pkill -u "$nome_usuario" >/dev/null 2>&1

echo "sucesso"
