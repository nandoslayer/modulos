#!/bin/sh

nome_usuario=$1

if [ "$nome_usuario" = "root" ]; then
    echo "erro"
    exit 1
else
    pkill -u $nome_usuario >/dev/null 2>&1
    userdel $nome_usuario 1>/dev/null 2>/dev/null

    if [ ! -f /root/usuarios.db ]; then
        touch /root/usuarios.db
    fi

    grep -v "^$nome_usuario[[:space:]]" /root/usuarios.db > /tmp/temp_db
    cat /tmp/temp_db > /root/usuarios.db

    rm -f /etc/SSHPlus/senha/$nome_usuario 1>/dev/null 2>/dev/null
    rm -f /etc/usuarios/$nome_usuario 1>/dev/null 2>/dev/null
    rm -f /etc/TesteAtlas/$nome_usuario.sh 1>/dev/null 2>/dev/null

    pkill -u $nome_usuario >/dev/null 2>&1

    echo "sucesso"
fi
