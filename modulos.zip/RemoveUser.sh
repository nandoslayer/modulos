#!/bin/bash

nome_usuario="$1"

if [ "$nome_usuario" = "root" ]; then
    echo "erro"
    exit 1
fi

userdel -f -r "$nome_usuario" >/dev/null 2>&1

[ -f /root/usuarios.db ] && sed -i "/^$nome_usuario[[:space:]]/d" /root/usuarios.db

rm -f /etc/SSHPlus/senha/"$nome_usuario" \
      /etc/usuarios/"$nome_usuario" \
      /etc/TesteAtlas/"$nome_usuario.sh" >/dev/null 2>&1

pkill -u "$nome_usuario" >/dev/null 2>&1

echo "sucesso"
