#!/bin/sh

USR_EX=$1

# Se o usuário for "root", encerra com código 2
if [ "$USR_EX" = "root" ]; then
    echo "2"
    exit 1
else
    # Remove o usuário e suas configurações
	pkill -u $USR_EX >/dev/null 2>&1
    userdel $USR_EX 1>/dev/null 2>/dev/null
	
	# Verificar se o arquivo usuarios.db existe; se não, criar
    if [ ! -f /root/usuarios.db ]; then
    touch /root/usuarios.db
    fi

    # Atualiza o arquivo de banco de dados de usuários
    grep -v "^$USR_EX[[:space:]]" /root/usuarios.db > /tmp/ph
    cat /tmp/ph > /root/usuarios.db

    # Remove arquivos relacionados ao usuário, saídas silenciadas
    rm /etc/SSHPlus/senha/$USR_EX 1>/dev/null 2>/dev/null
    rm /etc/usuarios/$USR_EX 1>/dev/null 2>/dev/null
    rm /etc/TesteAtlas/$USR_EX.sh 1>/dev/null 2>/dev/null

    # Mata os processos relacionados ao usuário
    pkill -u $USR_EX >/dev/null 2>&1

    # Indica sucesso
    echo "1"
fi
