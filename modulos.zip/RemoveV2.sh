#!/bin/bash

nome_usuario=$1
uuid_remover=$2

arquivo_temp_v2ray=$(mktemp)
arquivo_temp_xray=$(mktemp)

configurou_v2ray=false
configurou_xray=false

if [ -f /etc/v2ray/config.json ]; then
    if jq --arg uuid "$uuid_remover" '.inbounds[0].settings.clients |= map(select(.id != $uuid))' /etc/v2ray/config.json > "$arquivo_temp_v2ray" 2>/dev/null; then
        mv "$arquivo_temp_v2ray" /etc/v2ray/config.json
        chmod 644 /etc/v2ray/config.json
        configurou_v2ray=true
    fi
fi

if [ -f /usr/local/etc/xray/config.json ]; then
    if jq --arg uuid "$uuid_remover" '.inbounds |= map(if .tag == "inbound-sshplus" and (.settings.clients // null) then .settings.clients |= map(select(.id != $uuid)) else . end)' /usr/local/etc/xray/config.json > "$arquivo_temp_xray" 2>/dev/null; then
        mv "$arquivo_temp_xray" /usr/local/etc/xray/config.json
        chmod 644 /usr/local/etc/xray/config.json
        configurou_xray=true
    fi
fi

if [ "$configurou_v2ray" = false ] && [ "$configurou_xray" = false ]; then
    exit 0
fi

if systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray 2>/dev/null
fi

if systemctl is-active --quiet xray; then
    sudo systemctl restart xray 2>/dev/null
fi

sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" 2>/dev/null

echo "sucesso"


