#!/bin/bash

nome_usuario="$1"
uuid_remover="$2"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"
config_x3u="/usr/local/x-ui/bin/config.json"
tag_xray="inbound-sshplus"
tag_x3u="inbound-80"

configurou_v2ray=false
configurou_xray=false
configurou_x3u=false

# V2Ray
if sudo test -f "$config_v2ray"; then
    sudo jq --arg uuid "$uuid_remover" '
        .inbounds[0].settings.clients |= map(select(.id != $uuid))
    ' "$config_v2ray" | sudo tee "$config_v2ray" >/dev/null
    sudo chmod 777 "$config_v2ray"
    configurou_v2ray=true
fi

# XRay
if sudo test -f "$config_xray"; then
    sudo jq --arg uuid "$uuid_remover" --arg tag "$tag_xray" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" | sudo tee "$config_xray" >/dev/null
    sudo chmod 777 "$config_xray"
    configurou_xray=true
fi

# X-UI/X3U
if sudo test -f "$config_x3u"; then
    sudo jq --arg uuid "$uuid_remover" --arg tag "$tag_x3u" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_x3u" | sudo tee "$config_x3u" >/dev/null
    sudo chmod 777 "$config_x3u"
    configurou_x3u=true
fi

if [ "$configurou_v2ray" = false ] && [ "$configurou_xray" = false ] && [ "$configurou_x3u" = false ]; then
    exit 0
fi

# Reload/restart nos serviços
reload_or_restart() {
    local svc="$1"
    if sudo systemctl is-active --quiet "$svc"; then
        sudo systemctl reload "$svc" 2>/dev/null || sudo systemctl restart "$svc" 2>/dev/null
    fi
}

reload_or_restart v2ray
reload_or_restart xray
reload_or_restart x-ui

sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" 2>/dev/null

echo "sucesso"



