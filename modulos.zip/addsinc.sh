#!/bin/bash

uuiduser="$1"
email="$2"
senha="$3"
validade="$4"
limite="$5"

validade=$((validade + 1))

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

new_client="{\"email\": \"$email\", \"id\": \"$uuiduser\", \"level\": 0}"

if [ -f "$config_v2ray" ]; then
    tmpfile=$(mktemp)
    jq --arg uuid "$uuiduser" 'del(.inbounds[0].settings.clients[] | select(.id == $uuid))' "$config_v2ray" > "$tmpfile" 2>/dev/null && \
    mv "$tmpfile" "$config_v2ray" 2>/dev/null

    tmpfile=$(mktemp)
    jq --argjson newclient "$new_client" '.inbounds[0].settings.clients += [$newclient]' "$config_v2ray" > "$tmpfile" 2>/dev/null && \
    mv "$tmpfile" "$config_v2ray" 2>/dev/null
fi

if [ -f "$config_xray" ]; then
    tmpfile=$(mktemp)
    jq --arg uuid "$uuiduser" '.inbounds |= map(if .tag == "inbound-sshplus" and .settings.clients then .settings.clients |= map(select(.id != $uuid)) else . end)' "$config_xray" > "$tmpfile" 2>/dev/null && \
    mv "$tmpfile" "$config_xray" 2>/dev/null

    tmpfile=$(mktemp)
    jq --argjson newclient "$new_client" '.inbounds |= map(if .tag == "inbound-sshplus" and .settings.clients then .settings.clients += [$newclient] else . end)' "$config_xray" > "$tmpfile" 2>/dev/null && \
    mv "$tmpfile" "$config_xray" 2>/dev/null
fi

sudo bash /opt/apipainel/atlascreate.sh "$email" "$senha" "$validade" "$limite" 2>/dev/null
