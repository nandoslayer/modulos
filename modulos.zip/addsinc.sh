#!/bin/bash

uuiduser="$1"
email="$2@gmail.com"
senha="$3"
validade="$4"
limite="$5"
config_file="/etc/v2ray/config.json"

# Incrementar validade (dias + 1)
validade=$((validade + 1))

# Cria um arquivo temporário para modificar o arquivo de configuração
tmpfile=$(mktemp)

# Tenta modificar o JSON e apaga o cliente com base no UUID, saída silenciada
jq --arg uuid "$uuiduser" 'del(.inbounds[0].settings.clients[] | select(.id == $uuid))' "$config_file" > "$tmpfile" 2>/dev/null

# Tenta mover o arquivo temporário para o arquivo de configuração original, saída silenciada
mv "$tmpfile" "$config_file" 2>/dev/null

# Cria um novo cliente JSON com os parâmetros fornecidos
new_client="{\"email\": \"$email\", \"id\": \"$uuiduser\", \"level\": 0}"

# Cria um arquivo temporário para modificar o arquivo de configuração
tmpfile=$(mktemp)

# Tenta adicionar o novo cliente ao JSON de configuração, saída silenciada
jq --argjson newclient "$new_client" '.inbounds[0].settings.clients += [$newclient]' "$config_file" > "$tmpfile" 2>/dev/null

# Tenta mover o arquivo temporário para o arquivo de configuração original, saída silenciada
mv "$tmpfile" "$config_file" 2>/dev/null

# Tenta executar o script atlascreate.sh, saída silenciada
sudo bash /opt/apipainel/atlascreate.sh "$email" "$senha" "$validade" "$limite" 2>/dev/null

# Saída de sucesso se chegou até aqui
echo "1"