#!/bin/bash

login="$1"
uuidel="$2"

tmpfilev2ray=$(mktemp)
tmpfilexray=$(mktemp)

editou_v2ray=false
editou_xray=false

if [ -f /etc/v2ray/config.json ]; then
    if jq --arg uuid "$uuidel" '.inbounds[0].settings.clients |= map(select(.id != $uuid))' /etc/v2ray/config.json > "$tmpfilev2ray" 2>/dev/null; then
        mv "$tmpfilev2ray" /etc/v2ray/config.json
        chmod 644 /etc/v2ray/config.json
        editou_v2ray=true
    fi
fi

if [ -f /usr/local/etc/xray/config.json ]; then
    if jq --arg uuid "$uuidel" '.inbounds |= map(if .tag == "inbound-sshplus" and (.settings.clients // null) then .settings.clients |= map(select(.id != $uuid)) else . end)' /usr/local/etc/xray/config.json > "$tmpfilexray" 2>/dev/null; then
        mv "$tmpfilexray" /usr/local/etc/xray/config.json
        chmod 644 /usr/local/etc/xray/config.json
        editou_xray=true
    fi
fi

if [ "$editou_v2ray" = false ] && [ "$editou_xray" = false ]; then
    exit 0
fi

if systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray 2>/dev/null
fi

if systemctl is-active --quiet xray; then
    sudo systemctl restart xray 2>/dev/null
fi

sudo bash /opt/apipainel/atlasremove.sh "$login" 2>/dev/null
sudo bash /opt/apipainel/atlasremove.sh "$login@gmail.com" 2>/dev/null


