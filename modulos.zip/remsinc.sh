#!/bin/bash

login="$1"
uuidel="$2"

tmpfilev2ray=$(mktemp)
tmpfilexray=$(mktemp)

editou_v2ray=false
editou_xray=false

if [ -f /etc/v2ray/config.json ]; then
    jq --arg uuid "$uuidel" 'del(.inbounds[0].settings.clients[] | select(.id == $uuid))' /etc/v2ray/config.json > "$tmpfilev2ray" 2>/dev/null && \
    mv "$tmpfilev2ray" /etc/v2ray/config.json 2>/dev/null
    editou_v2ray=true
fi

if [ -f /usr/local/etc/xray/config.json ]; then
    jq --arg uuid "$uuidel" '.inbounds |= map(if .tag == "inbound-sshplus" and .settings.clients then .settings.clients |= map(select(.id != $uuid)) else . end)' /usr/local/etc/xray/config.json > "$tmpfilexray" 2>/dev/null && \
    mv "$tmpfilexray" /usr/local/etc/xray/config.json 2>/dev/null
    editou_xray=true
fi

if [ "$editou_v2ray" = false ] && [ "$editou_xray" = false ]; then
    exit 0
fi

if systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray 2>/dev/null
fi

if systemctl is-active --quiet xray; then
    sudo systemctl restart xray 2>/dev/null
fi

sudo bash /opt/apipainel/atlasremove.sh "$login" 2>/dev/null
sudo bash /opt/apipainel/atlasremove.sh "$login@gmail.com" 2>/dev/null

echo "1"
