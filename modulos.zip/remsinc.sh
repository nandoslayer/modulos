#!/bin/bash

login="$1@gmail.com"
uuidel="$2"

# Cria um arquivo temporário
tmpfile=$(mktemp)

# Tenta modificar o JSON e apaga o cliente com base no UUID, saída silenciada
jq --arg uuid "$uuidel" 'del(.inbounds[0].settings.clients[] | select(.id == $uuid))' /etc/v2ray/config.json > "$tmpfile" 2>/dev/null

# Tenta mover o arquivo temporário de volta para a configuração original, saída silenciada
mv "$tmpfile" /etc/v2ray/config.json 2>/dev/null

# Tenta reiniciar o serviço v2ray, saída silenciada
sudo systemctl restart v2ray 2>/dev/null

# Executa o script atlasremove.sh com o login fornecido, saída silenciada
sudo bash /opt/apipainel/atlasremove.sh "$login" 2>/dev/null

# Saída de sucesso silenciosa
echo "1"