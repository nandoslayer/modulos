#!/bin/bash

nome_usuario="$1"

[ -z "$nome_usuario" ] && echo "erro" && exit 1

pkill -u "$nome_usuario" >/dev/null 2>&1

echo "sucesso"
exit 0
