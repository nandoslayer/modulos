#!/bin/bash
nome_usuario=$1
pkill -u $nome_usuario 2>/dev/null
clear
echo "sucesso"
exit 0
