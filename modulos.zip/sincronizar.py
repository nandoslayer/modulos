# -*- coding: utf-8 -*-
import os
import sys
import subprocess
import logging

# Caminho para o arquivo de log
log_file_path = "/opt/apipainel/error_log.txt"

# Tamanho máximo do log em bytes (300KB)
max_log_size = 300 * 1024  # 300KB

# Função para rotacionar o log
def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

# Configura o logger
def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,  # Inclui informações além de erros
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

# Função para executar comandos com subprocess
def executar_comando(comando, linha):
    try:
        subprocess.run(comando, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logging.info(f"Comando executado com sucesso: {' '.join(comando)} | Linha: {linha}")
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao executar comando: {' '.join(comando)} | Linha: {linha} | Erro: {e}")

# Função principal
def main():
    response = "error"

    # Verifica se o arquivo foi passado como argumento
    if len(sys.argv) < 2:
        logging.error("Nenhum arquivo foi especificado como argumento.")
        sys.exit(1)

    nome_arquivo = sys.argv[1]

    # Verifica se o arquivo existe
    if not os.path.exists(nome_arquivo):
        logging.error(f"O arquivo {nome_arquivo} não foi encontrado.")
        sys.exit(1)

    try:
        # Lê o arquivo e remove linhas vazias ou espaços extras
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]

        # Processa cada linha
        for linha in linhas:
            colunas = linha.split()
            if len(colunas) >= 5:
                # Executa 'addsinc.sh' se houver 5 colunas ou mais
                executar_comando(
                    ["sudo", "bash", "/opt/apipainel/addsinc.sh", colunas[4], colunas[0], colunas[1], colunas[2], colunas[3]],
                    linha
                )
            elif len(colunas) >= 4:
                # Executa 'atlassinc.sh' se houver 4 colunas
                executar_comando(
                    ["sudo", "bash", "/opt/apipainel/atlassinc.sh", colunas[0], colunas[1], colunas[2], colunas[3]],
                    linha
                )
            else:
                logging.error(f"Linha inválida no arquivo: {linha}")
                continue  # Ignora linhas inválidas

        # Remove o arquivo após processar todas as linhas
        os.remove(nome_arquivo)
        logging.info(f"Arquivo {nome_arquivo} processado e removido com sucesso.")
        response = "comandoenviadocomsucesso"
        print(response)
        sys.exit(0)  # Finaliza com sucesso

    except Exception as e:
        # Registra qualquer erro inesperado no log e remove o arquivo se ele existir
        logging.error(f"Erro inesperado: {e}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        sys.exit(1)  # Finaliza com erro

if __name__ == "__main__":
    rotate_log()  # Verifica e rotaciona o log se necessário
    setup_logger()  # Configura o logger
    main()  # Executa o script principal
