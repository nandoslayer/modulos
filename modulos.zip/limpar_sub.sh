#!/bin/bash

LOCKFILE="/opt/apipainel/lock_sub"
TIMESTAMP_FILE="$LOCKFILE.time"

# Impede execução simultânea
exec 9>"$LOCKFILE.lock"
flock -n 9 || {
    echo "⛔ Já está rodando. Abortando..."
    exit 1
}

# Verifica tempo da última execução
AGORA=$(date +%s)
ULTIMO=0
[ -f "$TIMESTAMP_FILE" ] && ULTIMO=$(cat "$TIMESTAMP_FILE")
DIF=$((AGORA - ULTIMO))

if [ "$DIF" -lt 300 ]; then
    echo "🕒 Última execução foi há apenas $DIF segundos. Abortando."
    exit 0
fi

# Atualiza timestamp
echo "$AGORA" > "$TIMESTAMP_FILE"

# Verifica se já estão vazios
if [ ! -s /etc/subuid ] && [ ! -s /etc/subgid ]; then
    echo "📭 Já estão vazios. Nada a fazer."
    exit 0
fi

# Executa truncate
truncate -s 0 /etc/subuid
truncate -s 0 /etc/subgid
echo "✅ Arquivos limpos com sucesso."
