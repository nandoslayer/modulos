#!/bin/bash
USR_EX=$1
USR_EX2=$2

# Tenta matar todos os processos do usuário, independentemente da existência do usuário
pkill -u $USR_EX 2>/dev/null

# Limpa a tela
clear

# Exibe "1" sempre, já que estamos tentando matar os processos em qualquer condição
echo "1"

exit 0
