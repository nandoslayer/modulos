#!/bin/bash

if [ -f /etc/openvpn/openvpn-status.log ] && [ -f /var/log/v2ray/access.log ]; then
  ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$' || true
  sed '/^10.8.0./d' /etc/openvpn/openvpn-status.log | grep 127.0.0.1 | awk -F',' '{print $1}'
  echo 'status' | nc -q0 127.0.0.1 7505 | grep -oP '.*?,\K.*?(?=,)' | sort | uniq | grep -v : || true
  awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '$0 > date && /email:/ { sub(/.*email: /, "", $0); sub(/@gmail\.com$/, "", $0); if (!seen[$0]++) print }' /var/log/v2ray/access.log

elif [ -f /etc/openvpn/openvpn-status.log ]; then
  ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$' || true
  sed '/^10.8.0./d' /etc/openvpn/openvpn-status.log | grep 127.0.0.1 | awk -F',' '{print $1}'
  echo 'status' | nc -q0 127.0.0.1 7505 | grep -oP '.*?,\K.*?(?=,)' | sort | uniq | grep -v : || true

elif [ -f /var/log/v2ray/access.log ]; then
  ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$' || true
  awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '$0 > date && /email:/ { sub(/.*email: /, "", $0); sub(/@gmail\.com$/, "", $0); if (!seen[$0]++) print }' /var/log/v2ray/access.log

else
  ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$' || true
fi
