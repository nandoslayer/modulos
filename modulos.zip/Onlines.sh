#!/bin/bash

OUTFILE="/opt/apipainel/Onlines.json"
LOCKFILE="/opt/apipainel/Onlines.lock"
LOCKTIME=300  # 5 minutos

# Lock: Se existe e tem menos de 5 minutos, sai!
if [ -f "$LOCKFILE" ]; then
    mod_time=$(stat -c %Y "$LOCKFILE")
    now=$(date +%s)
    age=$((now - mod_time))
    if [ "$age" -lt "$LOCKTIME" ]; then
        echo "Já está rodando (lock com $age segundos)."
        exit 0
    else
        echo "Lock antigo, removendo."
        rm -f "$LOCKFILE"
    fi
fi

# Cria o lock com data/hora
date '+%Y-%m-%d %H:%M:%S' > "$LOCKFILE"

# Sempre remove o lock ao terminar (sucesso ou erro)
trap 'rm -f "$LOCKFILE"' EXIT

onlines=()

# SSH
while read -r user; do
    [ -n "$user" ] && onlines+=("$user")
done < <(ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$')

# OpenVPN
if [ -f /etc/openvpn/openvpn-status.log ]; then
    while read -r user; do
        [ -n "$user" ] && onlines+=("$user")
    done < <(sed '/^10.8.0./d' /etc/openvpn/openvpn-status.log | grep 127.0.0.1 | awk -F',' '{print $1}')
fi

# Trojan (porta 7505)
if nc -z 127.0.0.1 7505 2>/dev/null; then
    while read -r user; do
        [ -n "$user" ] && onlines+=("$user")
    done < <(echo 'status' | nc -q0 127.0.0.1 7505 | grep -oP '.*?,\K.*?(?=,)' | grep -v :)
fi

# V2Ray
if [ -f /var/log/v2ray/access.log ]; then
    while read -r user; do
        [ -n "$user" ] && onlines+=("$user")
    done < <(awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" \
        '$0 > date && /email:/ { sub(/.*email: /, "", $0); sub(/@gmail\.com$/, "", $0); if (!seen[$0]++) print }' /var/log/v2ray/access.log)
fi

# Monta JSON do jeito que você pediu
{
    echo -n '{"onlines":['
    for i in "${!onlines[@]}"; do
        printf '"%s"' "${onlines[$i]}"
        [[ $i -lt $((${#onlines[@]}-1)) ]] && echo -n ','
    done
    echo ']}'
} > "$OUTFILE"
