#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

v2ray_config_path = "/etc/v2ray/config.json"
xray_config_path = "/usr/local/etc/xray/config.json"

log_file_path = "/opt/apipainel/delete.log"
max_log_size = 512 * 1024
max_threads = 10

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        # Em vez de remover, melhor truncar para não perder todo histórico
        with open(log_file_path, "w") as f:
            f.truncate(0)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    logging.info("Logger iniciado.")

def reiniciar_servicos():
    services = {
        "v2ray": v2ray_config_path,
        "xray":  xray_config_path,
    }
    for servico, cfg_path in services.items():
        if not os.path.exists(cfg_path):
            logging.warning(f"Configuração ausente: {servico} -> {cfg_path}")
            continue
        try:
            acao = "restart" if subprocess.run(["systemctl", "is-active", "--quiet", servico]).returncode == 0 else "start"
            subprocess.run(["systemctl", acao, servico], check=True)
            logging.info(f"{acao.capitalize()} do serviço {servico} concluído.")
        except Exception as e:
            logging.error(f"Erro ao controlar {servico}: {e}")

def executar(cmd):
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        logging.error(f"Erro ao executar comando: {' '.join(cmd)}\n{e}")
        return False

def main():
    setup_logger()
    rotate_log()
    response = "error"
    algum_comando_executado = False

    if len(sys.argv) < 2:
        logging.error("Arquivo de entrada não especificado.")
        print(response)
        return 1

    nome_arquivo = sys.argv[1]
    if not os.path.exists(nome_arquivo):
        logging.error(f"Arquivo {nome_arquivo} inexistente.")
        print(response)
        return 1

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            linhas = [linha.strip() for linha in f if linha.strip()]

        # Se estiver vazio, remove o arquivo e encerra com erro
        if not linhas:
            logging.warning(f"Nenhuma linha válida no arquivo {nome_arquivo}.")
            os.remove(nome_arquivo)
            print(response)
            return 1

        comandos = []
        for linha in linhas:
            col = linha.strip().split()
            if len(col) >= 2:
                # Só usa login e uuid, ignora argumentos extras
                comandos.append(["bash", "/opt/apipainel/RemoveSincV2.sh", col[0], col[1]])
            elif len(col) == 1:
                comandos.append(["bash", "/opt/apipainel/RemoveUser.sh", col[0]])

        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            futures = [executor.submit(executar, cmd) for cmd in comandos]
            for future in as_completed(futures):
                if future.result():
                    algum_comando_executado = True

        os.remove(nome_arquivo)
        logging.info(f"Executado e removido: {nome_arquivo}")

        if algum_comando_executado:
            reiniciar_servicos()

        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        logging.error(f"Erro inesperado: {e}\n{traceback.format_exc()}")
        # Sempre remover o arquivo se ainda existir
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print(response)
        return 1

if __name__ == "__main__":
    sys.exit(main())
