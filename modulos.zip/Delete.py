#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import traceback

v2ray_config_path = "/etc/v2ray/config.json"
xray_config_path = "/usr/local/etc/xray/config.json"

log_file_path = "/opt/apipainel/delete.log"
max_log_size = 512 * 1024

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)
        logging.info("Log rotacionado: tamanho excedeu o limite.")

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    logging.info("Logger iniciado.")

def executar_comando(comando, linha):
    try:
        subprocess.run(comando, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        logging.info(f"Comando executado: {' '.join(comando)} | Linha: {linha}")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro comando: {' '.join(comando)} | Linha: {linha} | Erro: {e.stderr.decode().strip()}")
        return False
    except Exception as e:
        logging.error(f"Exceção comando: {' '.join(comando)} | Linha: {linha} | {e}\n{traceback.format_exc()}")
        return False

def reiniciar_servicos():
    services = {
        "v2ray": v2ray_config_path,
        "xray":  xray_config_path,
    }

    for servico, cfg_path in services.items():
        if not os.path.exists(cfg_path):
            logging.warning(f"Configuração ausente: {servico} -> {cfg_path}")
            continue

        try:
            is_active = subprocess.run(
                ["systemctl", "is-active", "--quiet", servico]
            ).returncode == 0

            acao = "restart" if is_active else "start"
            subprocess.run(["systemctl", acao, servico], check=True)
            logging.info(f"{acao.capitalize()} do serviço {servico} concluído.")
        except Exception as e:
            logging.error(f"Erro ao controlar {servico}: {e}")

def main():
    setup_logger()
    rotate_log()

    response = "error"
    algum_comando_executado = False

    if len(sys.argv) < 2:
        logging.error("Arquivo de entrada não especificado.")
        print(response)
        return 1

    nome_arquivo = sys.argv[1]

    if not os.path.exists(nome_arquivo):
        logging.error(f"Arquivo {nome_arquivo} inexistente.")
        print(response)
        return 1

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]

        for linha in linhas:
            colunas = linha.split()
            if len(colunas) >= 2:
                if executar_comando(["bash", "/opt/apipainel/RemoveSincV2.sh", colunas[0], colunas[1]], linha):
                    algum_comando_executado = True
            elif len(colunas) >= 1:
                if executar_comando(["bash", "/opt/apipainel/RemoveUser.sh", colunas[0]], linha):
                    algum_comando_executado = True
            else:
                logging.warning(f"Linha ignorada (colunas insuficientes): {linha}")

        os.remove(nome_arquivo)
        logging.info(f"Arquivo {nome_arquivo} removido após processamento.")

        if algum_comando_executado:
            reiniciar_servicos()

        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        logging.error(f"Erro inesperado: {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
            logging.info(f"Arquivo {nome_arquivo} removido após falha.")
        print(response)
        return 1

if __name__ == "__main__":
    sys.exit(main())
