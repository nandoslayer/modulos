# -*- coding: utf-8 -*-
import os
import sys
import subprocess
import logging
import traceback

v2ray_config_path = "/etc/v2ray/config.json"
xray_config_path = "/usr/local/etc/xray/config.json"

log_file_path = "/opt/apipainel/delete.log"
max_log_size = 512 * 1024

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def executar_comando(comando, linha):
    try:
        subprocess.run(comando, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        logging.info(f"Comando executado com sucesso: {' '.join(comando)}")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao executar comando: {' '.join(comando)} | Linha: {linha} | Erro: {e.stderr.decode().strip()}")
        print("error")
        return False

def reiniciar_servicos():
    services = {
        "v2ray": v2ray_config_path,
        "xray":  xray_config_path,
    }

    for servico, cfg_path in services.items():
        # Só reinicia/ativa se existir o arquivo JSON de configuração
        if not os.path.exists(cfg_path):
            logging.warning(f"Configuração para {servico} não encontrada em {cfg_path}; não reiniciou nem iniciou.")
            continue

        try:
            # verifica se está ativo
            is_active = (subprocess.run(
                ["systemctl", "is-active", "--quiet", servico]
            ).returncode == 0)

            if is_active:
                # se ativo, reinicia
                subprocess.run(
                    ["systemctl", "restart", servico],
                    check=True
                )
                logging.info(f"Serviço {servico} reiniciado com sucesso.")
            else:
                # se não está ativo, inicia (já garantimos que o JSON existe)
                subprocess.run(
                    ["systemctl", "start", servico],
                    check=True
                )
                logging.info(f"Serviço {servico} iniciado (config encontrado).")

        except Exception as e:
            logging.error(f"Erro no controle do serviço {servico}: {e}")

def main():
    response = "error"
    algum_comando_executado = False

    if len(sys.argv) < 2:
        logging.error("Nenhum arquivo foi especificado como argumento.")
        print(response)
        sys.exit(1)

    nome_arquivo = sys.argv[1]

    if not os.path.exists(nome_arquivo):
        logging.error(f"O arquivo {nome_arquivo} não foi encontrado.")
        print(response)
        sys.exit(1)

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]

        for linha in linhas:
            colunas = linha.split()
            if len(colunas) >= 2:
                if executar_comando(["sudo", "bash", "/opt/apipainel/RemoveSincV2.sh", colunas[0], colunas[1]], linha):
                    algum_comando_executado = True
            else:
                if executar_comando(["sudo", "bash", "/opt/apipainel/RemoveUser.sh", colunas[0]], linha):
                    algum_comando_executado = True

        os.remove(nome_arquivo)
        logging.info(f"Arquivo {nome_arquivo} processado e removido com sucesso.")

        if algum_comando_executado:
            reiniciar_servicos()

        response = "comandoenviadocomsucesso"
        print(response)
        sys.exit(0)

    except Exception as e:
        logging.error(f"Erro inesperado: {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print(response)
        sys.exit(1)

if __name__ == "__main__":
    rotate_log()
    setup_logger()
    main()
