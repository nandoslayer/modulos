#!/bin/bash
comando=$1

if [ "$comando" == "reboot" ]; then
    sleep 3
    echo "comandoenviadocomsucesso"
    sudo reboot > /dev/null 2>&1
elif [ "$comando" == "status" ]; then
    cpu_usage=$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')
    mem_usage=$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')
    echo "$cpu_usage $mem_usage"
elif [ "$comando" == "limpartudo" ]; then
    sleep 3
    # Mensagem de confirmação
    echo "comandoenviadocomsucesso"
    remove_ovp () {
        if [[ -e /etc/debian_version ]]; then
            GROUPNAME=nogroup
        fi
        user="$1"
        cd /etc/openvpn/easy-rsa/ > /dev/null 2>&1
        ./easyrsa --batch revoke $user > /dev/null 2>&1
        ./easyrsa gen-crl > /dev/null 2>&1
        rm -rf pki/reqs/$user.req > /dev/null 2>&1
        rm -rf pki/private/$user.key > /dev/null 2>&1
        rm -rf pki/issued/$user.crt > /dev/null 2>&1
        rm -rf /etc/openvpn/crl.pem > /dev/null 2>&1
        cp /etc/openvpn/easy-rsa/pki/crl.pem /etc/openvpn/crl.pem > /dev/null 2>&1
        chown nobody:$GROUPNAME /etc/openvpn/crl.pem > /dev/null 2>&1
        [[ -e $HOME/$user.ovpn ]] && rm $HOME/$user.ovpn > /dev/null 2>&1
        [[ -e /var/www/html/openvpn/$user.zip ]] && rm /var/www/html/openvpn/$user.zip > /dev/null 2>&1
    }

    # Limpa usuários do sistema
    for user in $(cat /etc/passwd | awk -F : '$3 > 900 {print $1}' | grep -vi "nobody"); do
        pkill -u $user > /dev/null 2>&1
        deluser --force $user > /dev/null 2>&1
        if [[ -e /etc/openvpn/server.conf ]]; then
            remove_ovp $user
        fi
    done

    # Limpa arquivos e dados específicos
    rm /etc/SSHPlus/senha/* > /dev/null 2>&1
    rm /etc/TesteAtlas/* > /dev/null 2>&1
    rm /etc/SSHPlus/Exp && touch /etc/SSHPlus/Exp > /dev/null 2>&1
    rm $HOME/usuarios.db && touch $HOME/usuarios.db > /dev/null 2>&1

    # Limpa clientes do JSON do V2Ray
    config_file="/etc/v2ray/config.json"
    tmpfile="/tmp/config_tmp.json"
    if [[ -e "$config_file" ]]; then
        jq 'del(.inbounds[0].settings.clients[])' "$config_file" > "$tmpfile" 2>/dev/null
        mv "$tmpfile" "$config_file"
    fi

elif [ "$comando" == "remover" ]; then
    sleep 3
    # Função para parar e desabilitar um serviço systemd
    stop_and_disable_service() {
        local service_name=$1
        if systemctl is-active --quiet $service_name; then
            systemctl stop $service_name >/dev/null 2>&1
            systemctl disable $service_name >/dev/null 2>&1
        fi
    }

    # Parar e desabilitar serviços
    stop_and_disable_service "modulo.service"

    # Remover arquivos e diretórios
    rm -rf /opt/apipainel >/dev/null 2>&1
    rm /etc/systemd/system/modulo.service >/dev/null 2>&1

    # Remover regras de firewall
    port=9060
    sudo firewall-cmd --zone=public --remove-port=$port/tcp --permanent >/dev/null 2>&1
    sudo firewall-cmd --reload >/dev/null 2>&1
    sudo iptables -D INPUT -p tcp --dport $port -j ACCEPT >/dev/null 2>&1
    sudo iptables-save | sudo tee /etc/iptables/rules.v4 >/dev/null 2>&1
    sudo ufw delete allow $port/tcp >/dev/null 2>&1

    # Limpar cron jobs
    crontab -l | grep -v 'verificador.sh' | crontab - >/dev/null 2>&1
    systemctl restart cron >/dev/null 2>&1
    echo "comandoenviadocomsucesso"
else
    echo "Invalid command"
fi
