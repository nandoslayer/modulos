#!/usr/bin/env python3
import sys
import os
import subprocess
import crypt
import pwd
from datetime import datetime, timedelta

usuario = sys.argv[1]
senha   = sys.argv[2]
dias    = int(sys.argv[3])
limite  = sys.argv[4]

exp      = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")
hash_pwd = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))

subprocess.run(
    ["bash", "/opt/apipainel/RemoveUser.sh", usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

for candidate in range(1000, 60000):
    if not any(u.pw_uid == candidate for u in pwd.getpwall()):
        ret = subprocess.run([
            "useradd", "-M", "-s", "/bin/false",
            "-u", str(candidate), "-p", hash_pwd,
            "-e", exp, usuario
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if ret.returncode == 0:
            break
else:
    subprocess.run([
        "useradd", "-M", "-s", "/bin/false",
        "-p", hash_pwd,
        "-e", exp, usuario
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

os.makedirs("/etc/SSHPlus/senha/", exist_ok=True)
with open(f"/etc/SSHPlus/senha/{usuario}", "w") as f:
    f.write(senha)
with open("/root/usuarios.db", "a") as f:
    f.write(f"{usuario} {limite}\n")

print("sucesso")
