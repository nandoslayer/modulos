#!/usr/bin/env python3

import sys
import os
import subprocess
import crypt
from datetime import datetime, timedelta

def get_next_uid():
    used_uids = set()
    with open("/etc/passwd", "r") as f:
        for line in f:
            parts = line.strip().split(":")
            if len(parts) >= 3:
                try:
                    uid = int(parts[2])
                    if uid >= 1000:
                        used_uids.add(uid)
                except ValueError:
                    continue
    return max(used_uids, default=999) + 1

nome_usuario = sys.argv[1]
senha = sys.argv[2]
dias = int(sys.argv[3])
limite_sessoes = sys.argv[4]

usuarios_db = "/root/usuarios.db"
senha_dir = "/etc/SSHPlus/senha/"

# Criação de diretórios se não existirem
os.makedirs(senha_dir, exist_ok=True)
if not os.path.isfile(usuarios_db):
    open(usuarios_db, 'a').close()

# Remove usuário anterior (caso exista)
subprocess.run(["bash", "/opt/apipainel/RemoveUser.sh", nome_usuario],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Criação do usuário com próximo UID disponível
senha_criptografada = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))
data_expira = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")
proximo_uid = get_next_uid()

subprocess.run([
    "useradd", "-M", "-s", "/bin/false",
    "-u", str(proximo_uid),
    "-p", senha_criptografada,
    "-e", data_expira,
    nome_usuario
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Armazena senha e sessões
with open(os.path.join(senha_dir, nome_usuario), "w") as f:
    f.write(senha)

with open(usuarios_db, "a") as f:
    f.write(f"{nome_usuario} {limite_sessoes}\n")

print("sucesso")
