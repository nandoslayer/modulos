#!/usr/bin/env python3

import sys
import os
import subprocess
import crypt
from datetime import datetime, timedelta

nome_usuario = sys.argv[1]
senha = sys.argv[2]
dias = int(sys.argv[3])
limite_sessoes = sys.argv[4]

usuarios_db = "/root/usuarios.db"
senha_dir = "/etc/SSHPlus/senha/"

# Criação de diretórios se não existirem
os.makedirs(senha_dir, exist_ok=True)
if not os.path.isfile(usuarios_db):
    open(usuarios_db, 'a').close()

# Remove usuário anterior (caso exista)
subprocess.run(["bash", "/opt/apipainel/RemoveUser.sh", nome_usuario],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Criação do usuário com senha criptografada
senha_criptografada = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))
data_expira = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")

subprocess.run([
    "useradd", "-M", "-s", "/bin/false",
    "-p", senha_criptografada,
    "-e", data_expira,
    nome_usuario
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Armazena senha e sessões
with open(os.path.join(senha_dir, nome_usuario), "w") as f:
    f.write(senha)

with open(usuarios_db, "a") as f:
    f.write(f"{nome_usuario} {limite_sessoes}\n")

print("sucesso")
