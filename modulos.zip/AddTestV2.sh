#!/bin/bash

uuid_usuario=$1
nome_usuario=$2
senha=$3
tempo_minutos="1440"
limite_sessoes=$5

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

novo_cliente="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

if [ -f "$config_v2ray" ]; then
    tmp_remover_v2ray=$(mktemp)
    jq --arg uuid "$uuid_usuario" '
        del(.inbounds[0].settings.clients[] | select(.id == $uuid))
    ' "$config_v2ray" > "$tmp_remover_v2ray" 2>/dev/null && mv "$tmp_remover_v2ray" "$config_v2ray"
    chmod 644 "$config_v2ray"
    
    tmp_adicionar_v2ray=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds[0].settings.clients += [$novo]
    ' "$config_v2ray" > "$tmp_adicionar_v2ray" 2>/dev/null && mv "$tmp_adicionar_v2ray" "$config_v2ray"
    chmod 644 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
    tmp_remover_xray=$(mktemp)
    jq --arg uuid "$uuid_usuario" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" > "$tmp_remover_xray" 2>/dev/null && mv "$tmp_remover_xray" "$config_xray"
    chmod 644 "$config_xray"

    tmp_adicionar_xray=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_xray" > "$tmp_adicionar_xray" 2>/dev/null && mv "$tmp_adicionar_xray" "$config_xray"
    chmod 644 "$config_xray"
fi

if systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray 2>/dev/null
fi

if systemctl is-active --quiet xray; then
    sudo systemctl restart xray 2>/dev/null
fi

if [ ! -f /root/usuarios.db ]; then
  touch /root/usuarios.db
fi

sudo bash /opt/apipainel/RemoveUser.sh $nome_usuario

data_expiracao=$(date "+%Y-%m-%d" -d "+2 days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")

useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

caminho_scripts="/etc/TesteAtlas"
mkdir -p "$caminho_scripts" >/dev/null 2>&1

conteudo_script="#!/bin/bash
sudo bash /opt/apipainel/RemoveUser.sh $nome_usuario
rm -f /etc/TesteAtlas/$nome_usuario.sh"

mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" > /etc/SSHPlus/senha/$nome_usuario

echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

echo "$conteudo_script" > "$caminho_scripts/$nome_usuario.sh"
chmod +x "$caminho_scripts/$nome_usuario.sh"

at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" min >/dev/null 2>&1

echo "sucesso"