#!/bin/bash
uuid_usuario="$1"
nome_usuario="$2"
senha="$3"
tempo_minutos="$4"
limite_sessoes="$5"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"
novo_cliente="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

if [ -f "$config_v2ray" ]; then
  tmp=$(mktemp)
  jq --argjson novo "$novo_cliente" \
    '.inbounds[0].settings.clients = [ $novo ] + ( (.inbounds[0].settings.clients // []) | map(select(.email != $novo.email and .id != $novo.id)) )' \
    "$config_v2ray" > "$tmp" && mv "$tmp" "$config_v2ray"
  chmod 777 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
  tmp=$(mktemp)
  jq --argjson novo "$novo_cliente" \
    '.inbounds = ( .inbounds | map(
        if .tag == "inbound-sshplus" then
          .settings.clients = [ $novo ] + ( (.settings.clients // []) | map(select(.email != $novo.email and .id != $novo.id)) )
        else . end
      ) )' \
    "$config_xray" > "$tmp" && mv "$tmp" "$config_xray"
  chmod 777 "$config_xray"
fi

if systemctl is-active --quiet v2ray; then
    systemctl restart v2ray >/dev/null 2>&1
elif [ -f "$config_v2ray" ]; then
    systemctl start v2ray >/dev/null 2>&1
fi

if systemctl is-active --quiet xray; then
    systemctl restart xray >/dev/null 2>&1
elif [ -f "$config_xray" ]; then
    systemctl start xray >/dev/null 2>&1
fi

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db

data_expira=$(date -d "+2 days" +%Y-%m-%d)
senha_criptografada=$(openssl passwd -1 "$senha")

useradd -M -s /bin/false -p "$senha_criptografada" -e "$data_expira" "$nome_usuario" >/dev/null 2>&1

mkdir -p /etc/SSHPlus/senha/
echo "$senha" > "/etc/SSHPlus/senha/$nome_usuario"
echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

caminho_scripts="/etc/TesteAtlas"
mkdir -p "$caminho_scripts"

cat <<EOF > "$caminho_scripts/$nome_usuario.sh"
#!/bin/bash
bash /opt/apipainel/RemoveV2.sh "$nome_usuario" "$uuid_usuario" >/dev/null 2>&1
rm -f "$caminho_scripts/$nome_usuario.sh"
EOF

chmod +x "$caminho_scripts/$nome_usuario.sh"

for job in $(atq | awk '{print $1}'); do
    at -c "$job" 2>/dev/null | grep -q "$caminho_scripts/$nome_usuario.sh" && atrm "$job"
done

at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" minutes >/dev/null 2>&1

echo "sucesso"
