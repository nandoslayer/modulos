#!/bin/bash

uuid_usuario=$1
nome_usuario=$2
senha=$3
tempo_minutos="$4"
limite_sessoes=$5

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"
config_x3u="/usr/local/x-ui/bin/config.json"
tag_xray="inbound-sshplus"
tag_x3u="inbound-80"

novo_cliente_x3u="{\"email\": \"$nome_usuario\", \"flow\": \"\", \"id\": \"$uuid_usuario\"}"
novo_cliente="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

# V2Ray
if sudo test -f "$config_v2ray"; then
    sudo jq --arg uuid "$uuid_usuario" '
        .inbounds[0].settings.clients |= map(select(.id != $uuid))
    ' "$config_v2ray" | sudo tee "$config_v2ray" >/dev/null
    echo "$novo_cliente" | sudo jq --argjson novo "$(cat)" '
        .inbounds[0].settings.clients += [$novo]
    ' "$config_v2ray" | sudo tee "$config_v2ray" >/dev/null
    sudo chmod 777 "$config_v2ray"
fi

# XRay
if sudo test -f "$config_xray"; then
    sudo jq --arg uuid "$uuid_usuario" --arg tag "$tag_xray" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" | sudo tee "$config_xray" >/dev/null
    echo "$novo_cliente" | sudo jq --argjson novo "$(cat)" --arg tag "$tag_xray" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_xray" | sudo tee "$config_xray" >/dev/null
    sudo chmod 777 "$config_xray"
fi

# X3U/X-UI
if sudo test -f "$config_x3u"; then
    sudo jq --arg uuid "$uuid_usuario" --arg tag "$tag_x3u" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_x3u" | sudo tee "$config_x3u" >/dev/null
    echo "$novo_cliente_x3u" | sudo jq --argjson novo "$(cat)" --arg tag "$tag_x3u" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_x3u" | sudo tee "$config_x3u" >/dev/null
    sudo chmod 777 "$config_x3u"
fi

# Função para reload ou restart
reload_or_restart() {
    local svc="$1"
    if sudo systemctl is-active --quiet "$svc"; then
        sudo systemctl reload "$svc" 2>/dev/null || sudo systemctl restart "$svc" 2>/dev/null
    fi
}

reload_or_restart v2ray
reload_or_restart xray
reload_or_restart x-ui

if ! sudo test -f /root/usuarios.db; then
    sudo touch /root/usuarios.db
    sudo chmod 777 /root/usuarios.db
fi

sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario"

data_expiracao=$(date "+%Y-%m-%d" -d "+2 days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")

sudo useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

caminho_scripts="/etc/TesteAtlas"
sudo mkdir -p "$caminho_scripts" >/dev/null 2>&1
sudo chmod 777 "$caminho_scripts"

conteudo_script="#!/bin/bash
sudo bash /opt/apipainel/RemoveV2.sh $nome_usuario $uuid_usuario
sudo rm -f /etc/TesteAtlas/$nome_usuario.sh"

sudo mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
sudo chmod 777 /etc/SSHPlus/senha/
echo "$senha" | sudo tee /etc/SSHPlus/senha/$nome_usuario >/dev/null
sudo chmod 777 /etc/SSHPlus/senha/$nome_usuario

echo "$nome_usuario $limite_sessoes" | sudo tee -a /root/usuarios.db >/dev/null

echo "$conteudo_script" | sudo tee "$caminho_scripts/$nome_usuario.sh" >/dev/null
sudo chmod 777 "$caminho_scripts/$nome_usuario.sh"

sudo at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" min >/dev/null 2>&1

echo "sucesso"
