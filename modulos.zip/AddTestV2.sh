#!/bin/bash

uuid_usuario="$1"
nome_usuario="$2"
senha="$3"
tempo_minutos="$4"
limite_sessoes="$5"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

novo_cliente="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

sudo bash /opt/apipainel/RemoveV2.sh "$nome_usuario" "$uuid_usuario" >/dev/null 2>&1

if [ -f "$config_v2ray" ]; then
    tmp_add=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds[0].settings.clients += [$novo]
    ' "$config_v2ray" > "$tmp_add" 2>/dev/null && sudo mv "$tmp_add" "$config_v2ray"
    sudo chmod 777 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
    tmp_add=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_xray" > "$tmp_add" 2>/dev/null && sudo mv "$tmp_add" "$config_xray"
    sudo chmod 777 "$config_xray"
fi

if sudo systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray >/dev/null 2>&1
elif [ -f "$config_v2ray" ]; then
    sudo systemctl start v2ray >/dev/null 2>&1
fi

if sudo systemctl is-active --quiet xray; then
    sudo systemctl restart xray >/dev/null 2>&1
elif [ -f "$config_xray" ]; then
    sudo systemctl start xray >/dev/null 2>&1
fi

[ ! -f /root/usuarios.db ] && sudo touch /root/usuarios.db

senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")
sudo useradd -M -s /bin/false -p "$senha_criptografada" -e "$(date -d "+2 days" +%Y-%m-%d)" "$nome_usuario" >/dev/null 2>&1

sudo mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" | sudo tee /etc/SSHPlus/senha/"$nome_usuario" >/dev/null

echo "$nome_usuario $limite_sessoes" | sudo tee -a /root/usuarios.db >/dev/null

caminho_scripts="/etc/TesteAtlas"
sudo mkdir -p "$caminho_scripts" >/dev/null 2>&1

cat <<EOF | sudo tee "$caminho_scripts/$nome_usuario.sh" >/dev/null
#!/bin/bash
sudo bash /opt/apipainel/RemoveV2.sh "$nome_usuario" "$uuid_usuario" >/dev/null 2>&1
sudo rm -f "$caminho_scripts/$nome_usuario.sh"
EOF

sudo chmod +x "$caminho_scripts/$nome_usuario.sh"

sudo at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" minutes >/dev/null 2>&1

echo "sucesso"
