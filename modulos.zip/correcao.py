import json
import os

v2ray_config_path = '/etc/v2ray/config.json'
xray_config_path = '/usr/local/etc/xray/config.json'
log_dir = '/var/log/v2ray'
access_log_path = os.path.join(log_dir, 'access.log')
error_log_path = os.path.join(log_dir, 'error.log')

os.makedirs(log_dir, exist_ok=True)
open(access_log_path, 'a').close()
open(error_log_path, 'a').close()

def patch_v2ray_log(config_path):
    if not os.path.exists(config_path):
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)
    config['log'] = {
        'access': access_log_path,
        'error': error_log_path,
        'loglevel': 'info'
    }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    os.chmod(config_path, 0o644)
    return True

def patch_xray_log(config_path):
    if not os.path.exists(config_path):
        return False
    with open(config_path, 'r') as f:
        config = json.load(f)
    config['log'] = {
        'access': access_log_path,
        'dnsLog': False,
        'error': error_log_path,
        'loglevel': 'info',
        'maskAddress': ''
    }
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    os.chmod(config_path, 0o644)
    return True

v2ray_ok = patch_v2ray_log(v2ray_config_path)
xray_ok = patch_xray_log(xray_config_path)

if v2ray_ok:
    os.system('systemctl restart v2ray')

if xray_ok:
    os.system('systemctl restart xray')

