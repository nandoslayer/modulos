import json
import os

config_path = '/etc/v2ray/config.json'
access_log_path = '/var/log/v2ray/access.log'
error_log_path = '/var/log/v2ray/error.log'

if not os.path.exists(config_path):
    exit(0)

os.makedirs(os.path.dirname(access_log_path), exist_ok=True)
open(access_log_path, 'a').close()
open(error_log_path, 'a').close()

with open(config_path, 'r') as f:
    config = json.load(f)

if 'log' not in config:
    new_config = {
        'log': {
            'access': access_log_path,
            'error': error_log_path,
            'loglevel': 'info'
        }
    }
    new_config.update(config)
    config = new_config

with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)

os.system('systemctl restart v2ray')
