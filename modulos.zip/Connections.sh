#!/bin/bash

total_ssh=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)
ssh_users=$(ps -x | grep sshd | grep -v root | grep priv | grep -v 'unknown' | grep -v '^[[:space:]]*$')

if [ -f /var/log/v2ray/access.log ]; then
  v2ray_users=$(awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '
    {
      log_time = substr($0, 1, 19)
      if (log_time > date && $0 ~ /email: /) {
        user = $0
        sub(/^.*email: /, "", user)
        sub(/ .*/, "", user)
        print user
      }
  }' /var/log/v2ray/access.log | sort | uniq)
else
  v2ray_users=""
fi

if [ -f /etc/openvpn/openvpn-status.log ]; then
  openvpn_users=$(awk -F',' '/,127\.0\.0\.1,/{print $1}' /etc/openvpn/openvpn-status.log | sort | uniq)
else
  openvpn_users=""
fi

all_users=$(echo -e "$ssh_users\n$v2ray_users\n$openvpn_users" | sort | uniq | grep -vE '^$')

if [ -z "$all_users" ]; then
  total_online_users=0
else
  total_online_users=$(echo "$all_users" | wc -l)
fi

echo "{"
echo "  \"total_ssh_users\": $total_ssh,"
echo "  \"total_online_users\": $total_online_users"
echo "}"