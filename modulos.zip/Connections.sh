#!/bin/bash

OUTFILE="/opt/apipainel/Connections.json"
LOCKFILE="/opt/apipainel/Connections.lock"
LOCKTIME=300  # 5 minutos

# Lock: Se existe e tem menos de 5 minutos, sai!
if [ -f "$LOCKFILE" ]; then
    mod_time=$(stat -c %Y "$LOCKFILE")
    now=$(date +%s)
    age=$((now - mod_time))
    if [ "$age" -lt "$LOCKTIME" ]; then
        echo "Já está rodando (lock com $age segundos)."
        exit 0
    else
        echo "Lock antigo, removendo."
        rm -f "$LOCKFILE"
    fi
fi

# Cria o lock com data/hora
date '+%Y-%m-%d %H:%M:%S' > "$LOCKFILE"

# Sempre remove o lock ao terminar (sucesso ou erro)
trap 'rm -f "$LOCKFILE"' EXIT

total_ssh=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)

ssh_sessions=$(ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$' | grep -v '^$')
# Conta TODAS as sessões (até repetidas, sem unique)
total_ssh_online_sessions=$(echo "$ssh_sessions" | grep -c .)

# Se quiser a lista dos usuários (com possíveis repetições)
ssh_users_list="$ssh_sessions"

if [ -f /var/log/v2ray/access.log ]; then
  v2ray_users=$(awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '
    {
      log_time = substr($0, 1, 19)
      if (log_time > date && $0 ~ /email: /) {
        user = $0
        sub(/^.*email: /, "", user)
        sub(/ .*/, "", user)
        print user
      }
  }' /var/log/v2ray/access.log)
else
  v2ray_users=""
fi

if [ -f /etc/openvpn/openvpn-status.log ]; then
  openvpn_users=$(awk -F',' '/,127\.0\.0\.1,/{print $1}' /etc/openvpn/openvpn-status.log)
else
  openvpn_users=""
fi

# Remove usuários do v2ray e openvpn que já estão na lista SSH (com ou sem repetição, funciona)
v2ray_not_in_ssh=$(comm -23 <(echo "$v2ray_users" | sort) <(echo "$ssh_sessions" | sort))
openvpn_not_in_ssh=$(comm -23 <(echo "$openvpn_users" | sort) <(echo "$ssh_sessions" | sort))

total_v2ray=$(echo "$v2ray_not_in_ssh" | grep -c .)
total_openvpn=$(echo "$openvpn_not_in_ssh" | grep -c .)

total_online_users=$((total_ssh_online_sessions + total_v2ray + total_openvpn))

cat <<EOF > "$OUTFILE"
{
  "total_ssh_users": $total_ssh,
  "total_ssh_online_sessions": $total_ssh_online_sessions,
  "total_v2ray": $total_v2ray,
  "total_openvpn": $total_openvpn,
  "total_online_users": $total_online_users
}
EOF
