#!/bin/bash

# Contagem total de usuários SSH válidos (do sistema, não necessariamente online)
total_ssh=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)

# SSH: usuários online únicos (tirando root/nobody/vazio)
ssh_users=$(ps -x | grep sshd | grep -v root | grep priv | grep -v 'unknown' | grep -v '^[[:space:]]*$')

# V2Ray: emails únicos ativos nos últimos 60s
if [ -f /var/log/v2ray/access.log ]; then
  v2ray_users=$(awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '
    {
      log_time = substr($0, 1, 19)
      if (log_time > date && $0 ~ /email: /) {
        user = $0
        sub(/^.*email: /, "", user)
        sub(/ .*/, "", user)
        print user
      }
  }' /var/log/v2ray/access.log | sort | uniq)
else
  v2ray_users=""
fi

# OpenVPN: usuários únicos ativos, se log existir
if [ -f /etc/openvpn/openvpn-status.log ]; then
  openvpn_users=$(awk -F',' '/,127\.0\.0\.1,/{print $1}' /etc/openvpn/openvpn-status.log | sort | uniq)
else
  openvpn_users=""
fi

# Junta todos usuários e pega só os únicos
all_users=$(echo -e "$ssh_users\n$v2ray_users\n$openvpn_users" | sort | uniq | grep -vE '^$')
total_online_users=$(echo "$all_users" | wc -l)

# Exibir saída em JSON
echo "{"
echo "  \"total_ssh_users\": $total_ssh,"
echo "  \"total_online_users\": $total_online_users"
echo "}"
