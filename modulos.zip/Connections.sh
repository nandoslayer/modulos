#!/bin/bash

total_ssh=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)

ssh_sessions=$(ps -ef | grep -oP 'sshd: \K\S+(?= \[priv\])' | grep -Ev '^(root|unknown|""|\s*)$')
total_ssh_online_sessions=$(echo "$ssh_sessions" | grep -v '^$' | wc -l)

if [ -f /var/log/v2ray/access.log ]; then
  v2ray_users=$(awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '
    {
      log_time = substr($0, 1, 19)
      if (log_time > date && $0 ~ /email: /) {
        user = $0
        sub(/^.*email: /, "", user)
        sub(/ .*/, "", user)
        print user
      }
  }' /var/log/v2ray/access.log)
else
  v2ray_users=""
fi

if [ -f /etc/openvpn/openvpn-status.log ]; then
  openvpn_users=$(awk -F',' '/,127\.0\.0\.1,/{print $1}' /etc/openvpn/openvpn-status.log)
else
  openvpn_users=""
fi

total_v2ray=$(echo "$v2ray_users" | grep -v '^$' | wc -l)
total_openvpn=$(echo "$openvpn_users" | grep -v '^$' | wc -l)

total_online_sessions=$(( total_ssh_online_sessions + total_v2ray + total_openvpn ))

echo "{"
echo "  \"total_ssh_users\": $total_ssh,"
echo "  \"total_ssh_online_sessions\": $total_ssh_online_sessions,"
echo "  \"total_v2ray\": $total_v2ray,"
echo "  \"total_openvpn\": $total_openvpn,"
echo "  \"total_online_users\": $total_online_sessions"
echo "}"
