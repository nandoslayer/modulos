#!/bin/bash

# Contagem total de usuários SSH válidos
total_ssh=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody | wc -l)

# Contagem de conexões SSH ativas (excluindo root, unknown e vazios)
ssh_users=$(ps -x | grep sshd | grep -v root | grep priv)
ssh_count=$(echo "$ssh_users" | wc -l)

# Contagem de conexões OpenVPN ativas
if [ -f /etc/openvpn/openvpn-status.log ]; then
  openvpn_users=$(sed '/^10.8.0./d' /etc/openvpn/openvpn-status.log | grep 127.0.0.1 | awk -F',' '{print $1}')
  openvpn_count=$(echo "$openvpn_users" | wc -l)
else
  openvpn_users=""
  openvpn_count=0
fi

if [ -f /var/log/v2ray/access.log ]; then
  v2ray_users=$(awk -v date="$(date -d '60 seconds ago' +'%Y/%m/%d %H:%M:%S')" '
    {
      log_time = substr($0, 1, 19)
      if (log_time > date && $0 ~ /email: /) {
        match($0, /email: [^ ]+/, arr)
        if (arr[0] != "")
          gsub(/email: /, "", arr[0])
          print arr[0]
      }
  }' /var/log/v2ray/access.log | sort -u)

  v2ray_count=$(echo "$v2ray_users" | grep -c .)
else
  v2ray_users=""
  v2ray_count=0
fi

# Identificar usuários presentes em mais de um serviço
multi_service_users=$(echo -e "$ssh_users\n$openvpn_users\n$v2ray_users" | sort | uniq -d)

# Contar apenas usuários que aparecem em múltiplos serviços
multi_service_count=$(echo "$multi_service_users" | wc -l)

# Calcular total de usuários online sem remover duplicatas dentro do mesmo serviço
total_online_users=$((ssh_count + openvpn_count + v2ray_count - multi_service_count))

# Garantir que os valores não sejam negativos
if [ "$total_online_users" -lt 0 ]; then total_online_users=0; fi

# Exibir saída em JSON apenas com Total Users e Total Online Users
echo "{"
echo "  \"total_ssh_users\": $total_ssh,"
echo "  \"total_online_users\": $total_online_users"
echo "}"
