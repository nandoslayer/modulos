#!/bin/bash

uuiduser="$1"
email="$2"
senha="$3"
validadem="1440"
limite="$5"
validaded="2"

folder_path="/etc/TesteAtlas"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

mkdir -p "$folder_path" >/dev/null 2>&1

new_client="{\"email\": \"$email\", \"id\": \"$uuiduser\", \"level\": 0}"

if [ -f "$config_v2ray" ]; then
    tmp_v2ray_remove=$(mktemp)
    jq --arg uuid "$uuiduser" '
        del(.inbounds[0].settings.clients[] | select(.id == $uuid))
    ' "$config_v2ray" > "$tmp_v2ray_remove" 2>/dev/null && mv "$tmp_v2ray_remove" "$config_v2ray"
    chmod 644 "$config_v2ray"
    
    tmp_v2ray_add=$(mktemp)
    jq --argjson newclient "$new_client" '
        .inbounds[0].settings.clients += [$newclient]
    ' "$config_v2ray" > "$tmp_v2ray_add" 2>/dev/null && mv "$tmp_v2ray_add" "$config_v2ray"
    chmod 644 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
    tmp_xray_remove=$(mktemp)
    jq --arg uuid "$uuiduser" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" > "$tmp_xray_remove" 2>/dev/null && mv "$tmp_xray_remove" "$config_xray"
    chmod 644 "$config_xray"

    tmp_xray_add=$(mktemp)
    jq --argjson newclient "$new_client" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients += [$newclient]
            else .
            end
        )
    ' "$config_xray" > "$tmp_xray_add" 2>/dev/null && mv "$tmp_xray_add" "$config_xray"
    chmod 644 "$config_xray"
fi

if systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray 2>/dev/null
fi

if systemctl is-active --quiet xray; then
    sudo systemctl restart xray 2>/dev/null
fi

sudo bash /opt/apipainel/atlasteste.sh "$email" "$senha" "$validaded" "$limite" >/dev/null 2>&1

rem_script="$folder_path/$email.sh"
echo -e "#!/bin/bash\nsudo bash /opt/apipainel/remsinc.sh $email $uuiduser" > "$rem_script"
chmod 777 "$rem_script"

at -f "$rem_script" now + "$validadem" min >/dev/null 2>&1
