#!/bin/bash

uuiduser="$1"
email="$2@gmail.com"
senha="$3"
validade="$4"
limite="$5"
config_file="/etc/v2ray/config.json"
folder_path="/etc/TesteAtlas"

# Cria o diretório se não existir, saída silenciada
mkdir -p "$folder_path" >/dev/null 2>&1

# Cria um arquivo temporário para modificar o arquivo de configuração, saída silenciada
tmpfile=$(mktemp)

# Tenta modificar o JSON e apaga o cliente com base no UUID, saída silenciada
jq --arg uuid "$uuiduser" 'del(.inbounds[0].settings.clients[] | select(.id == $uuid))' "$config_file" > "$tmpfile" 2>/dev/null

# Tenta mover o arquivo temporário para o arquivo de configuração original, saída silenciada
mv "$tmpfile" "$config_file" 2>/dev/null

# Cria um novo cliente JSON com os parâmetros fornecidos
new_client="{\"email\": \"$email\", \"id\": \"$uuiduser\", \"level\": 0}"

# Cria um arquivo temporário para modificar o arquivo de configuração, saída silenciada
tmpfile=$(mktemp)

# Tenta adicionar o novo cliente ao JSON de configuração, saída silenciada
jq --argjson newclient "$new_client" '.inbounds[0].settings.clients += [$newclient]' "$config_file" > "$tmpfile" 2>/dev/null

# Tenta mover o arquivo temporário para o arquivo de configuração original, saída silenciada
mv "$tmpfile" "$config_file" 2>/dev/null

# Tenta reiniciar o serviço v2ray, saída silenciada
sudo systemctl restart v2ray 2>/dev/null

# Executa o script atlasteste.sh, saída silenciada
sudo bash /opt/apipainel/atlasteste.sh "$email" "$senha" "$validade" "$limite" >/dev/null 2>&1

# Cria o conteúdo do script de exclusão
script_content="#!/bin/bash
sudo bash /opt/apipainel/remsinc.sh $email $uuiduser"

# Cria o script de exclusão no diretório apropriado
echo "$script_content" > "$folder_path/$email.sh"

# Torna o script executável
chmod +x "$folder_path/$email.sh"

# Agendar o script de exclusão para execução após $validade minutos, saída silenciada
at -f "$folder_path/$email.sh" now + $validade min >/dev/null 2>&1

# Saída de sucesso
echo "CRIADOCOMSUCESSO"