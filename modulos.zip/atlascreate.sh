#!/bin/bash

username=$1
password=$2
dias=$3
sshlimiter=$4

# Remover usuário existente e limpar arquivos relacionados, saída silenciada
pkill -u $username >/dev/null 2>&1
userdel $username 1>/dev/null 2>/dev/null
rm -f /etc/SSHPlus/senha/$username 1>/dev/null 2>/dev/null
rm -f /etc/usuarios/$username 1>/dev/null 2>/dev/null
rm -f /etc/TesteAtlas/$username.sh 1>/dev/null 2>/dev/null
pkill -u $username >/dev/null 2>&1

# Verificar se o arquivo usuarios.db existe; se não, criar
if [ ! -f /root/usuarios.db ]; then
  touch /root/usuarios.db
fi

# Remover o usuário do banco de dados, saída silenciada
grep -v ^$username[[:space:]] /root/usuarios.db > /tmp/ph && cat /tmp/ph > /root/usuarios.db

# Calcular a data de expiração
final=$(date "+%Y-%m-%d" -d "+$dias days")

# Criptografar a senha
pass=$(perl -e 'print crypt($ARGV[0], "password")' $password)

# Criar o novo usuário com a data de expiração e a senha criptografada
useradd -e $final -M -s /bin/false -p $pass $username

# Criar o diretório de senhas se não existir e salvar a senha, saída silenciada
mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$password" > /etc/SSHPlus/senha/$username

# Adicionar o usuário ao banco de dados com o limite de sessões SSH
echo "$username $sshlimiter" >> /root/usuarios.db

# Exibe "1" ao final, indicando sucesso
echo "1"
