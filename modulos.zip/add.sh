#!/bin/bash

uuiduser="$1"
email="$2"
senha="$3"
validade="$4"
limite="$5"

validade=$((validade + 1))

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

new_client="{\"email\": \"$email\", \"id\": \"$uuiduser\", \"level\": 0}"

if [ -f "$config_v2ray" ]; then
    temp_v2ray_remove=$(mktemp)
    jq --arg uuid "$uuiduser" '
      del(.inbounds[0].settings.clients[] | select(.id == $uuid))
    ' "$config_v2ray" > "$temp_v2ray_remove" 2>/dev/null && mv "$temp_v2ray_remove" "$config_v2ray"

    chmod 644 "$config_v2ray"

    temp_v2ray_add=$(mktemp)
    jq --argjson newclient "$new_client" '
      .inbounds[0].settings.clients += [$newclient]
    ' "$config_v2ray" > "$temp_v2ray_add" 2>/dev/null && mv "$temp_v2ray_add" "$config_v2ray"

    chmod 644 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
    tmp_xray_remove=$(mktemp)
    jq --arg uuid "$uuiduser" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" > "$tmp_xray_remove" 2>/dev/null && mv "$tmp_xray_remove" "$config_xray"

    chmod 644 "$config_xray"

    tmp_xray_add=$(mktemp)
    jq --argjson newclient "$new_client" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients += [$newclient]
            else .
            end
        )
    ' "$config_xray" > "$tmp_xray_add" 2>/dev/null && mv "$tmp_xray_add" "$config_xray"

    chmod 644 "$config_xray"
fi

sudo bash /opt/apipainel/atlascreate.sh "$email" "$senha" "$validade" "$limite" 2>/dev/null
