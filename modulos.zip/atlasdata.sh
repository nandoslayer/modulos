#!/bin/bash

usuario=$1
dias=$2

# Calcula a data de expiração
finaldate=$(date "+%Y-%m-%d" -d "+$dias days")

# Define a data de expiração da conta
chage -E "$finaldate" "$usuario"

# Exibe "1" ao final para indicar sucesso
echo "1"