#!/bin/bash

uuid_usuario=$1
nome_usuario=$2
senha=$3
dias=$4
limite_sessoes=$5

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

novo_cliente="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

if [ -f "$config_v2ray" ]; then
    temp_v2ray_remover=$(mktemp)
    jq --arg uuid "$uuid_usuario" '
        del(.inbounds[0].settings.clients[] | select(.id == $uuid))
    ' "$config_v2ray" > "$temp_v2ray_remover" 2>/dev/null && mv "$temp_v2ray_remover" "$config_v2ray"
    chmod 644 "$config_v2ray"

    temp_v2ray_adicionar=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds[0].settings.clients += [$novo]
    ' "$config_v2ray" > "$temp_v2ray_adicionar" 2>/dev/null && mv "$temp_v2ray_adicionar" "$config_v2ray"
    chmod 644 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
    temp_xray_remover=$(mktemp)
    jq --arg uuid "$uuid_usuario" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" > "$temp_xray_remover" 2>/dev/null && mv "$temp_xray_remover" "$config_xray"
    chmod 644 "$config_xray"

    temp_xray_adicionar=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null)
            then .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_xray" > "$temp_xray_adicionar" 2>/dev/null && mv "$temp_xray_adicionar" "$config_xray"
    chmod 644 "$config_xray"
fi

if systemctl is-active --quiet v2ray; then
    sudo systemctl restart v2ray 2>/dev/null
fi

if systemctl is-active --quiet xray; then
    sudo systemctl restart xray 2>/dev/null
fi

if [ ! -f /root/usuarios.db ]; then
    touch /root/usuarios.db
fi

sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" 2>/dev/null

data_expiracao=$(date "+%Y-%m-%d" -d "+$dias days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")

useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" > /etc/SSHPlus/senha/$nome_usuario

echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

echo "sucesso"

