#!/bin/bash

uuid_usuario="$1"
nome_usuario="$2"
senha="$3"
dias="$4"
limite_sessoes="$5"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"
novo_cliente="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

if [ -f "$config_v2ray" ]; then
    tmp_add=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds[0].settings.clients |= (
            [ $novo ] + map(select(!( .email == $novo.email or .id == $novo.id )))
        )
    ' "$config_v2ray" > "$tmp_add" && mv "$tmp_add" "$config_v2ray"
    chmod 777 "$config_v2ray"
fi

if [ -f "$config_xray" ]; then
    tmp_add=$(mktemp)
    jq --argjson novo "$novo_cliente" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null) then
                .settings.clients |= (
                    [ $novo ] + map(select(!( .email == $novo.email or .id == $novo.id )))
                )
            else .
            end
        )
    ' "$config_xray" > "$tmp_add" && mv "$tmp_add" "$config_xray"
    chmod 777 "$config_xray"
fi

if systemctl is-active --quiet v2ray; then
    systemctl restart v2ray >/dev/null 2>&1
elif [ -f "$config_v2ray" ]; then
    systemctl start v2ray >/dev/null 2>&1
fi

if systemctl is-active --quiet xray; then
    systemctl restart xray >/dev/null 2>&1
elif [ -f "$config_xray" ]; then
    systemctl start xray >/dev/null 2>&1
fi

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db

# 🔎 Detecta o próximo UID livre a partir de 1000
get_next_uid() {
    awk -F: '$3 >= 1000 { print $3 }' /etc/passwd | sort -n | awk 'END { print $1 + 1 }'
}
proximo_uid=$(get_next_uid)

# 🔐 Cria o usuário com UID livre e validade em dias
senha_criptografada=$(openssl passwd -1 "$senha")
data_expira=$(date -d "+$dias days" +%Y-%m-%d)

useradd -M -s /bin/false -u "$proximo_uid" -p "$senha_criptografada" -e "$data_expira" "$nome_usuario" >/dev/null 2>&1

mkdir -p /etc/SSHPlus/senha/
echo "$senha" > "/etc/SSHPlus/senha/$nome_usuario"
echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

echo "sucesso"
