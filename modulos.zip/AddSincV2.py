#!/usr/bin/env python3
import sys
import os
import subprocess
import crypt
import json
from datetime import datetime, timedelta

uuid_usuario = sys.argv[1]
nome_usuario = sys.argv[2]
senha = sys.argv[3]
dias = int(sys.argv[4])
limite = sys.argv[5]

config_v2ray = "/etc/v2ray/config.json"
config_xray = "/usr/local/etc/xray/config.json"
senha_path = f"/etc/SSHPlus/senha/{nome_usuario}"
novo_cliente = {"email": nome_usuario, "id": uuid_usuario, "level": 0}

subprocess.run(["bash", "/opt/apipainel/RemoveUser.sh", nome_usuario], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def update_json(path, update_fn):
    try:
        with open(path, 'r') as f:
            data = json.load(f)
    except Exception:
        return False
    modified = update_fn(data)
    if not modified:
        return False
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)
    os.chmod(path, 0o777)
    return True

if os.path.isfile(config_v2ray):
    def fn_v2(data):
        clients = data.get('inbounds', [])[0].get('settings', {}).get('clients', [])
        filtered = [c for c in clients if c.get('email') != nome_usuario]
        data['inbounds'][0]['settings']['clients'] = [novo_cliente] + filtered
        return True
    update_json(config_v2ray, fn_v2)

if os.path.isfile(config_xray):
    def fn_xray(data):
        changed = False
        for ib in data.get('inbounds', []):
            if ib.get('tag') == 'inbound-sshplus':
                clients = ib.get('settings', {}).get('clients', [])
                filtered = [c for c in clients if c.get('email') != nome_usuario]
                ib['settings']['clients'] = [novo_cliente] + filtered
                changed = True
        return changed
    update_json(config_xray, fn_xray)

exp = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")
hash_pwd = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))
subprocess.run([
    "useradd", "-M", "-s", "/bin/false",
    "-p", hash_pwd, "-e", exp, nome_usuario
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

os.makedirs(os.path.dirname(senha_path), exist_ok=True)
with open(senha_path, "w") as f:
    f.write(senha)

usuarios_db = "/root/usuarios.db"
def append_unique(path, line):
    lines = []
    if os.path.isfile(path):
        with open(path, 'r') as f:
            lines = [l.strip() for l in f if l.strip()]
    if line not in lines:
        lines.append(line)
        with open(path, 'w') as f:
            f.write("\n".join(lines) + "\n")
append_unique(usuarios_db, f"{nome_usuario} {limite}")

print("sucesso")
