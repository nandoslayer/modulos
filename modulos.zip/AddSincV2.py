#!/usr/bin/env python3
import sys, os, subprocess, json, crypt, pwd
from datetime import datetime, timedelta

uuid_usuario = sys.argv[1]
nome_usuario = sys.argv[2]
senha         = sys.argv[3]
dias          = int(sys.argv[4])
limite        = sys.argv[5]

config_v2ray = "/etc/v2ray/config.json"
config_xray  = "/usr/local/etc/xray/config.json"
senha_path   = f"/etc/SSHPlus/senha/{nome_usuario}"
novo_cliente = {"email": nome_usuario, "id": uuid_usuario, "level": 0}

for cfg, tag in ((config_v2ray, "v2ray"), (config_xray, "xray")):
    if os.path.isfile(cfg):
        try:
            data = json.load(open(cfg))
        except:
            continue
        if tag == "v2ray":
            cl = data["inbounds"][0]["settings"]["clients"]
            data["inbounds"][0]["settings"]["clients"] = [c for c in cl if c.get("email") != nome_usuario] + [novo_cliente]
        else:
            for ib in data["inbounds"]:
                if ib.get("tag") == "inbound-sshplus":
                    cl = ib["settings"].get("clients", [])
                    ib["settings"]["clients"] = [c for c in cl if c.get("email") != nome_usuario] + [novo_cliente]
        with open(cfg, "w") as f:
            json.dump(data, f, indent=2)
        os.chmod(cfg, 0o777)

subprocess.run(
    ["bash", "/opt/apipainel/RemoveUser.sh", nome_usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

exp      = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")
hash_pwd = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))

for candidate in range(1000, 60000):
    if not any(u.pw_uid == candidate for u in pwd.getpwall()):
        r = subprocess.run([
            "useradd", "-M", "-s", "/bin/false",
            "-u", str(candidate), "-p", hash_pwd,
            "-e", exp, nome_usuario
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if r.returncode == 0:
            break
else:
    subprocess.run([
        "useradd", "-M", "-s", "/bin/false",
        "-p", hash_pwd,
        "-e", exp, nome_usuario
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

os.makedirs(os.path.dirname(senha_path), exist_ok=True)
with open(senha_path, "w") as f:
    f.write(senha)
with open("/root/usuarios.db", "a") as f:
    f.write(f"{nome_usuario} {limite}\n")

print("sucesso")
