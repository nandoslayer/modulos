#!/usr/bin/env python3

import sys
import os
import json
import subprocess
import crypt
from datetime import datetime, timedelta

def get_next_uid():
    used_uids = set()
    with open("/etc/passwd", "r") as f:
        for line in f:
            parts = line.strip().split(":")
            if len(parts) >= 3:
                try:
                    uid = int(parts[2])
                    if uid >= 1000:
                        used_uids.add(uid)
                except ValueError:
                    continue
    return max(used_uids, default=999) + 1

uuid_usuario = sys.argv[1]
nome_usuario = sys.argv[2]
senha = sys.argv[3]
dias = int(sys.argv[4])
limite_sessoes = sys.argv[5]

config_v2ray = "/etc/v2ray/config.json"
config_xray = "/usr/local/etc/xray/config.json"
senha_path = f"/etc/SSHPlus/senha/{nome_usuario}"

novo_cliente = {
    "email": nome_usuario,
    "id": uuid_usuario,
    "level": 0
}

# Remove usuário antigo
subprocess.run(["bash", "/opt/apipainel/RemoveUser.sh", nome_usuario],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def atualizar_json(caminho, seletor, novo):
    if not os.path.isfile(caminho):
        return
    try:
        with open(caminho, 'r') as f:
            data = json.load(f)
    except Exception:
        return

    if seletor == "v2ray":
        clients = data["inbounds"][0]["settings"]["clients"]
        clients = [c for c in clients if c.get("email") != novo["email"] and c.get("id") != novo["id"]]
        clients.insert(0, novo)
        data["inbounds"][0]["settings"]["clients"] = clients
    elif seletor == "xray":
        for inbound in data["inbounds"]:
            if inbound.get("tag") == "inbound-sshplus" and "clients" in inbound.get("settings", {}):
                clients = inbound["settings"]["clients"]
                clients = [c for c in clients if c.get("email") != novo["email"] and c.get("id") != novo["id"]]
                clients.insert(0, novo)
                inbound["settings"]["clients"] = clients

    with open(caminho, 'w') as f:
        json.dump(data, f, indent=2)
    os.chmod(caminho, 0o777)

# Atualiza JSONs
atualizar_json(config_v2ray, "v2ray", novo_cliente)
atualizar_json(config_xray, "xray", novo_cliente)

# Cria usuário local com próximo UID disponível
data_expira = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")
senha_criptografada = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))
proximo_uid = get_next_uid()

subprocess.run([
    "useradd", "-M", "-s", "/bin/false",
    "-u", str(proximo_uid),
    "-p", senha_criptografada,
    "-e", data_expira,
    nome_usuario
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Salva senha e limite
os.makedirs("/etc/SSHPlus/senha/", exist_ok=True)
with open(senha_path, "w") as f:
    f.write(senha)

with open("/root/usuarios.db", "a+") as f:
    f.write(f"{nome_usuario} {limite_sessoes}\n")

print("sucesso")
