#!/bin/bash

uuid_usuario="$1"
nome_usuario="$2"
senha="$3"
dias="$4"
limite_sessoes="$5"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"
config_x3u="/usr/local/x-ui/bin/config.json"

tag_xray="inbound-sshplus"   # Ajuste se o inbound do XRay for diferente
tag_x3u="inbound-80"         # Tag do seu inbound X-UI/X3U

# Cliente para X-UI/X3U (com flow)
novo_cliente_x3u="{\"email\": \"$nome_usuario\", \"flow\": \"\", \"id\": \"$uuid_usuario\"}"
# Cliente para XRay e V2Ray (sem flow)
novo_cliente_simple="{\"email\": \"$nome_usuario\", \"id\": \"$uuid_usuario\", \"level\": 0}"

# --- V2Ray ---
if [ -f "$config_v2ray" ]; then
    sudo jq --arg uuid "$uuid_usuario" '
        .inbounds[0].settings.clients |= map(select(.id != $uuid))
    ' "$config_v2ray" > "$config_v2ray.tmp" && mv "$config_v2ray.tmp" "$config_v2ray"
    sudo chmod 777 "$config_v2ray"

    sudo jq --argjson novo "$novo_cliente_simple" '
        .inbounds[0].settings.clients += [$novo]
    ' "$config_v2ray" > "$config_v2ray.tmp" && mv "$config_v2ray.tmp" "$config_v2ray"
    sudo chmod 777 "$config_v2ray"
	
fi

# --- XRAY ---
if [ -f "$config_xray" ]; then
    sudo jq --arg uuid "$uuid_usuario" --arg tag "$tag_xray" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" > "$config_xray.tmp" && mv "$config_xray.tmp" "$config_xray"
    sudo chmod 777 "$config_xray"

    sudo jq --argjson novo "$novo_cliente_simple" --arg tag "$tag_xray" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_xray" > "$config_xray.tmp" && mv "$config_xray.tmp" "$config_xray"
    sudo chmod 777 "$config_xray"
	
fi

# --- X-UI/X3U ---
if [ -f "$config_x3u" ]; then
    # Remove usuário do array clients (id)
    sudo jq --arg uuid "$uuid_usuario" --arg tag "$tag_x3u" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_x3u" > "$config_x3u.tmp" && mv "$config_x3u.tmp" "$config_x3u"
    sudo chmod 777 "$config_x3u"

    # Adiciona usuário ao array clients
    sudo jq --argjson novo "$novo_cliente_x3u" --arg tag "$tag_x3u" '
        .inbounds |= map(
            if .tag == $tag and (.settings.clients // null)
            then .settings.clients += [$novo]
            else .
            end
        )
    ' "$config_x3u" > "$config_x3u.tmp" && mv "$config_x3u.tmp" "$config_x3u"
    sudo chmod 777 "$config_x3u"
	
fi

if ! sudo test -f /root/usuarios.db; then
    sudo touch /root/usuarios.db
    sudo chmod 777 /root/usuarios.db
fi

sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" 2>/dev/null

data_expiracao=$(date "+%Y-%m-%d" -d "+$dias days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")

sudo useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

sudo mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" | sudo tee /etc/SSHPlus/senha/$nome_usuario >/dev/null

echo "$nome_usuario $limite_sessoes" | sudo tee -a /root/usuarios.db >/dev/null

echo "sucesso"