# -*- coding: utf-8 -*-
import os
import sys
import subprocess
import logging

log_file_path = "/opt/apipainel/error_log.txt"
max_log_size = 300 * 1024

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def executar_comando(comando, linha):
    try:
        subprocess.run(comando, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logging.info(f"Comando executado com sucesso: {' '.join(comando)} | Linha: {linha}")
    except subprocess.CalledProcessError as e:
        logging.error(f"Erro ao executar comando: {' '.join(comando)} | Linha: {linha} | Erro: {e}")

def reiniciar_servicos():
    services = {
        "v2ray": v2ray_config_path,
        "xray":  xray_config_path,
    }

    for servico, cfg_path in services.items():
        try:
            # verifica se está ativo
            is_active = (subprocess.run(
                ["systemctl", "is-active", "--quiet", servico]
            ).returncode == 0)

            if is_active:
                # se ativo, reinicia
                subprocess.run(
                    ["systemctl", "restart", servico],
                    check=True
                )
                logging.info(f"Serviço {servico} reiniciado com sucesso.")
            else:
                # se não está ativo, só inicia se o JSON existir
                if os.path.exists(cfg_path):
                    subprocess.run(
                        ["systemctl", "start", servico],
                        check=True
                    )
                    logging.info(f"Serviço {servico} iniciado (config encontrado).")
                else:
                    logging.warning(
                        f"Configuração para {servico} não encontrada em {cfg_path}; não iniciou."
                    )

        except Exception as e:
            logging.error(f"Erro no controle do serviço {servico}: {e}")

def main():
    response = "error"
    if len(sys.argv) < 2:
        logging.error("Nenhum arquivo foi especificado como argumento.")
        sys.exit(1)

    nome_arquivo = sys.argv[1]
    if not os.path.exists(nome_arquivo):
        logging.error(f"O arquivo {nome_arquivo} não foi encontrado.")
        sys.exit(1)

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]

        for linha in linhas:
            colunas = linha.split()
            if len(colunas) >= 5:
                executar_comando(
                    ["sudo", "bash", "/opt/apipainel/AddSincV2.sh", colunas[4], colunas[0], colunas[1], colunas[2], colunas[3]],
                    linha
                )
            elif len(colunas) >= 4:
                executar_comando(
                    ["sudo", "bash", "/opt/apipainel/AddUser.sh", colunas[0], colunas[1], colunas[2], colunas[3]],
                    linha
                )
            else:
                logging.error(f"Linha inválida no arquivo: {linha}")
                continue

        os.remove(nome_arquivo)
        logging.info(f"Arquivo {nome_arquivo} processado e removido com sucesso.")
        reiniciar_servicos()
        response = "comandoenviadocomsucesso"
        print(response)
        sys.exit(0)

    except Exception as e:
        logging.error(f"Erro inesperado: {e}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        sys.exit(1)

if __name__ == "__main__":
    rotate_log()
    setup_logger()
    main()
