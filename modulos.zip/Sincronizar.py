#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import traceback
import time
import fcntl

v2ray_config_path = "/etc/v2ray/config.json"
xray_config_path = "/usr/local/etc/xray/config.json"

log_file_path = "/opt/apipainel/sincronizar.log"
lock_file_path = "/opt/apipainel/sincronizar.lock"
max_log_size = 512 * 1024
max_lock_age = 30 * 60

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)
        logging.info("Log rotacionado: tamanho excedeu o limite.")

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    logging.info("Logger configurado.")

def aplicar_lock(lock_path, nome_arquivo=None):
    if os.path.exists(lock_path):
        try:
            with open(lock_path, 'r') as f:
                conteudo = f.read().strip()
                lock_timestamp = int(conteudo) if conteudo.isdigit() else 0
        except Exception:
            lock_timestamp = 0

        if lock_timestamp and (time.time() - lock_timestamp > max_lock_age):
            logging.warning("Lockfile antigo detectado. Removendo.")
            os.remove(lock_path)
        else:
            logging.error("Outra instância do script já está em execução.")
            if nome_arquivo and os.path.exists(nome_arquivo):
                os.remove(nome_arquivo)
                logging.info(f"Arquivo '{nome_arquivo}' removido devido à execução concorrente.")
            print("error")
            sys.exit(1)

    lock_file = open(lock_path, 'w+')
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_file.write(str(int(time.time())))
        lock_file.flush()
        logging.info("Lockfile adquirido com sucesso.")
        return lock_file
    except BlockingIOError:
        logging.error("Falha ao obter lock (BlockingIOError).")
        if nome_arquivo and os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
            logging.info(f"Arquivo '{nome_arquivo}' removido devido à execução concorrente.")
        print("error")
        sys.exit(1)

def remover_lock(lock_file, lock_path):
    try:
        fcntl.flock(lock_file, fcntl.LOCK_UN)
        lock_file.close()
        if os.path.exists(lock_path):
            os.remove(lock_path)
        logging.info("Lockfile liberado e removido.")
    except Exception as e:
        logging.error(f"Erro ao remover lockfile: {e}")

def executar_comando(comando, linha):
    logging.info(f"Iniciando execução do comando: {' '.join(comando)} | Linha de dados: {linha}")
    try:
        subprocess.run(comando, check=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        logging.info(f"Comando concluído: {' '.join(comando)}")
        return True
    except subprocess.CalledProcessError:
        logging.error(f"Falha ao executar comando: {' '.join(comando)} | Linha: {linha}")
        print("error")
        return False
    except Exception as e:
        logging.error(f"Exceção inesperada ao executar comando: {' '.join(comando)} | Linha: {linha} | {e}\n{traceback.format_exc()}")
        print("error")
        return False

def reiniciar_servicos():
    services = {
        "v2ray": v2ray_config_path,
        "xray":  xray_config_path,
    }

    for servico, cfg_path in services.items():
        logging.info(f"Verificando serviço '{servico}' com configuração em '{cfg_path}'.")
        if not os.path.exists(cfg_path):
            logging.warning(f"Configuração para '{servico}' não encontrada em '{cfg_path}'; ignorando reinício/início.")
            continue

        try:
            is_active = (subprocess.run(["systemctl", "is-active", "--quiet", servico]).returncode == 0)

            if is_active:
                logging.info(f"'{servico}' está ativo. Tentando reiniciar.")
                subprocess.run(["systemctl", "restart", servico], check=True)
                logging.info(f"Serviço '{servico}' reiniciado com sucesso.")
            else:
                logging.info(f"'{servico}' não está ativo. Tentando iniciar.")
                subprocess.run(["systemctl", "start", servico], check=True)
                logging.info(f"Serviço '{servico}' iniciado com sucesso.")
        except Exception as e:
            logging.error(f"Exceção inesperada ao controlar '{servico}': {e}\n{traceback.format_exc()}")

def main():
    response = "error"
    algum_comando_executado = False
    logging.info("Início do processamento no main().")

    if len(sys.argv) < 2:
        logging.error("Nenhum arquivo foi especificado como argumento.")
        print(response)
        return 1

    nome_arquivo = sys.argv[1]
    logging.info(f"Arquivo recebido para processamento: '{nome_arquivo}'")

    if not os.path.exists(nome_arquivo):
        logging.error(f"O arquivo '{nome_arquivo}' não foi encontrado.")
        print(response)
        return 1

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]
        logging.info(f"{len(linhas)} linha(s) lida(s) do arquivo '{nome_arquivo}'.")

        for linha in linhas:
            colunas = linha.split()
            logging.info(f"Processando linha: '{linha}' -> colunas: {colunas}")
            if len(colunas) >= 5:
                cmd = ["bash", "/opt/apipainel/AddSincV2.sh",
                       colunas[4], colunas[0], colunas[1], colunas[2], colunas[3]]
                if executar_comando(cmd, linha):
                    algum_comando_executado = True
            elif len(colunas) >= 4:
                cmd = ["bash", "/opt/apipainel/AddUser.sh",
                       colunas[0], colunas[1], colunas[2], colunas[3]]
                if executar_comando(cmd, linha):
                    algum_comando_executado = True
            else:
                logging.warning(f"Linha inválida (menos de 4 colunas): '{linha}'")
                continue

        os.remove(nome_arquivo)
        logging.info(f"Arquivo '{nome_arquivo}' processado e removido com sucesso.")

        if algum_comando_executado:
            logging.info("Algum comando foi executado com sucesso; iniciando reinício de serviços.")
            reiniciar_servicos()
        else:
            logging.info("Nenhum comando válido foi executado; pulando reinício de serviços.")

        response = "comandoenviadocomsucesso"
        print(response)
        logging.info("Fim do processamento na main() com sucesso.")
        return 0

    except Exception as e:
        logging.error(f"Erro inesperado no main(): {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
            logging.info(f"Arquivo '{nome_arquivo}' removido após erro.")
        print(response)
        return 1

if __name__ == "__main__":
    rotate_log()
    setup_logger()
    nome_arquivo = sys.argv[1] if len(sys.argv) > 1 else None
    lock_file = aplicar_lock(lock_file_path, nome_arquivo)

    try:
        sys.exit(main())
    finally:
        remover_lock(lock_file, lock_file_path)
