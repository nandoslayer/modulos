#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

log_file_path = "/opt/apipainel/sincronizar.log"
max_log_size = 512 * 1024
max_threads = 10

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def reiniciar_servicos():
    for servico, cfg in {
        "v2ray": "/etc/v2ray/config.json",
        "xray": "/usr/local/etc/xray/config.json"
    }.items():
        if not os.path.exists(cfg):
            continue
        try:
            ativo = subprocess.run(["systemctl", "is-active", "--quiet", servico]).returncode == 0
            subprocess.run(["systemctl", "restart" if ativo else "start", servico], check=True)
        except Exception as e:
            logging.error(f"Erro ao reiniciar {servico}: {e}")

def executar(cmd):
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        logging.error(f"Erro ao executar comando: {' '.join(cmd)}\n{e}")
        return False

def main():
    rotate_log()
    setup_logger()

    if len(sys.argv) < 2:
        print("error")
        return 1

    nome_arquivo = sys.argv[1]
    if not os.path.exists(nome_arquivo):
        print("error")
        return 1

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            linhas = [l.strip() for l in f if l.strip()]

        if not linhas:
            os.remove(nome_arquivo)
            print("error")
            return 1

        comandos = []
        for linha in linhas:
            col = linha.split()
            if len(col) >= 5:
                comandos.append(["/bin/bash", "/opt/apipainel/AddSincV2.sh", col[4], col[0], col[1], col[2], col[3]])
            elif len(col) >= 4:
                comandos.append(["/bin/bash", "/opt/apipainel/AddUser.sh", col[0], col[1], col[2], col[3]])

        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            futures = [executor.submit(executar, cmd) for cmd in comandos]
            for _ in as_completed(futures):
                pass  # aguarda todos

        os.remove(nome_arquivo)
        reiniciar_servicos()

        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        logging.error(f"Erro: {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print("error")
        return 1

if __name__ == "__main__":
    sys.exit(main())
