#!/usr/bin/env python3
import os
import sys
import subprocess
import json
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

log_file_path = "/opt/apipainel/sincronizar.log"
max_log_size = 512 * 1024
python_path = sys.executable

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def remover_duplicados_v2ray(path):
    if not os.path.exists(path):
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)

        seen_ids = set()
        seen_emails = set()
        clients = []
        for client in data["inbounds"][0]["settings"]["clients"]:
            cid = client.get("id")
            email = client.get("email")
            if cid in seen_ids or email in seen_emails:
                continue
            seen_ids.add(cid)
            seen_emails.add(email)
            clients.append(client)

        data["inbounds"][0]["settings"]["clients"] = clients
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(path, 0o777)
    except Exception as e:
        logging.error(f"Erro ao limpar duplicatas V2Ray: {e}")

def remover_duplicados_xray(path):
    if not os.path.exists(path):
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)

        for inbound in data.get("inbounds", []):
            if inbound.get("tag") != "inbound-sshplus":
                continue
            seen_ids = set()
            seen_emails = set()
            clients = []
            for client in inbound.get("settings", {}).get("clients", []):
                cid = client.get("id")
                email = client.get("email")
                if cid in seen_ids or email in seen_emails:
                    continue
                seen_ids.add(cid)
                seen_emails.add(email)
                clients.append(client)
            inbound["settings"]["clients"] = clients

        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(path, 0o777)
    except Exception as e:
        logging.error(f"Erro ao limpar duplicatas XRay: {e}")

def reiniciar_servicos():
    remover_duplicados_v2ray("/etc/v2ray/config.json")
    remover_duplicados_xray("/usr/local/etc/xray/config.json")

    for servico, cfg in {
        "v2ray": "/etc/v2ray/config.json",
        "xray": "/usr/local/etc/xray/config.json"
    }.items():
        if not os.path.exists(cfg):
            continue
        try:
            ativo = subprocess.run(["systemctl", "is-active", "--quiet", servico]).returncode == 0
            subprocess.run(["systemctl", "restart" if ativo else "start", servico], check=True)
        except Exception as e:
            logging.error(f"Erro ao reiniciar {servico}: {e}")

def executar(cmd):
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        logging.error(f"Erro ao executar: {' '.join(cmd)}\n{e}")
        return False

def main():
    rotate_log()
    setup_logger()

    if len(sys.argv) < 2:
        print("error")
        return 1

    nome_arquivo = sys.argv[1]
    if not os.path.exists(nome_arquivo):
        print("error")
        return 1

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            linhas = [l.strip() for l in f if l.strip()]

        if not linhas:
            os.remove(nome_arquivo)
            print("error")
            return 1

        comandos = []
        for linha in linhas:
            logging.info(f"Executando linha: {linha}")
            col = linha.split()
            if len(col) >= 5:
                comandos.append([
                    python_path,
                    "/opt/apipainel/AddSincV2.py",
                    col[4], col[0], col[1], col[2], col[3]
                ])
            elif len(col) >= 4:
                comandos.append([
                    python_path,
                    "/opt/apipainel/AddUser.py",
                    col[0], col[1], col[2], col[3]
                ])

        with ThreadPoolExecutor() as executor:
            futures = [executor.submit(executar, cmd) for cmd in comandos]
            for _ in as_completed(futures):
                pass

        os.remove(nome_arquivo)
        reiniciar_servicos()

        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        logging.error(f"Erro: {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print("error")
        return 1

if __name__ == "__main__":
    sys.exit(main())
