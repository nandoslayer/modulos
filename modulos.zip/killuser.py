# -*- coding: utf-8 -*-
import os
import sys
import subprocess
import logging

# Caminho para o arquivo de log
log_file_path = "/opt/apipainel/erro_killuser_log.txt"

# Tamanho máximo do log em bytes (300KB)
max_log_size = 300 * 1024  # 300KB

# Função para rotacionar o log
def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)  # Apenas remove o log sem backup

# Configura o logger
def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def main():
    response = "error"
    nome_arquivo = sys.argv[1]

    # Verifica se o arquivo existe
    if not os.path.exists(nome_arquivo):
        logging.error(f"O arquivo {nome_arquivo} não foi encontrado.")
        print(response)
        sys.exit(1)

    try:
        # Lê o arquivo e remove linhas vazias ou espaços extras
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]

        # Processa cada linha como uma string completa (sem divisão em colunas)
        for linha in linhas:
            try:
                # Aqui você passa a linha completa como argumento para o script
                subprocess.run(
                    ["sudo", "bash", "/opt/apipainel/killuserapi.sh", linha],
                    check=True,
                    stdout=subprocess.PIPE,  # Captura stdout
                    stderr=subprocess.PIPE   # Captura stderr
                )
                logging.info(f"Processado com sucesso: {linha}")
            except subprocess.CalledProcessError as e:
                logging.error(f"Erro ao executar o comando com linha: {linha} - {e.stderr.decode().strip()}")
                print(response)

        # Remove o arquivo após processar todas as linhas
        os.remove(nome_arquivo)

        response = "success"
        print(response)
        sys.exit(0)

    except Exception as e:
        # Em caso de erro, registra no log
        logging.error(f"Erro inesperado: {e}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print(response)
        sys.exit(1)

if __name__ == "__main__":
    rotate_log()  # Verifica e rotaciona o log se necessário
    setup_logger()  # Configura o logger
    main()  # Executa o script principal
