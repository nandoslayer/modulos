#!/bin/bash

username=$1
password=$2
dias=$3
sshlimiter=$4

# Remover usuário existente e limpar arquivos relacionados
pkill -u $username >/dev/null 2>&1
userdel $username >/dev/null 2>&1
rm -f /etc/SSHPlus/senha/$username >/dev/null 2>&1
rm -f /etc/usuarios/$username >/dev/null 2>&1
rm -f /etc/TesteAtlas/$username.sh >/dev/null 2>&1
pkill -u $username >/dev/null 2>&1

# Verificar se o arquivo usuarios.db existe; se não, criar
if [ ! -f /root/usuarios.db ]; then
  touch /root/usuarios.db
fi

# Remover o usuário do banco de dados
grep -v "^$username[[:space:]]" /root/usuarios.db > /tmp/ph && mv /tmp/ph /root/usuarios.db >/dev/null 2>&1

# Calcular a data de expiração
final=$(date "+%Y-%m-%d" -d "+2 days")

# Criptografar a senha
pass=$(perl -e 'print crypt($ARGV[0], "password")' "$password")

# Criar o novo usuário com a data de expiração e a senha criptografada
useradd -e "$final" -M -s /bin/false -p "$pass" "$username" >/dev/null 2>&1

folder_path="/etc/TesteAtlas"

# Cria o diretório se não existir
mkdir -p "$folder_path" >/dev/null 2>&1

script_content="#!/bin/bash
sudo bash /opt/apipainel/atlasremove.sh $username"

# Cria o diretório de senhas se não existir
mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$password" > /etc/SSHPlus/senha/$username

# Adicionar o usuário ao banco de dados com o limite de sessões SSH
echo "$username $sshlimiter" >> /root/usuarios.db

# Cria o script de exclusão e agenda sua execução
echo "$script_content" > "$folder_path/$username.sh"
chmod +x "$folder_path/$username.sh"

# Agendar o script de exclusão para executar após $dias minutos
at -f "$folder_path/$username.sh" now + "$dias" min >/dev/null 2>&1

# Mensagem de sucesso
echo "CRIADOCOMSUCESSO"