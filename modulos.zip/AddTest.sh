#!/bin/bash

nome_usuario="$1"
senha="$2"
tempo_minutos="$3"
limite_sessoes="$4"

db="/root/usuarios.db"
caminho_scripts="/etc/TesteAtlas"
senha_dir="/etc/SSHPlus/senha"

# Garante existência dos arquivos e diretórios, com permissão 777
if ! sudo test -f "$db"; then
    sudo touch "$db"
fi
sudo chmod 777 "$db"

sudo mkdir -p "$caminho_scripts" "$senha_dir"
sudo chmod 777 "$caminho_scripts" "$senha_dir"

# Remove o usuário antigo (silencioso)
sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

# Cria o usuário com senha e expiração
data_expiracao=$(date "+%Y-%m-%d" -d "+2 days")
senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")
sudo useradd -e "$data_expiracao" -M -s /bin/false -p "$senha_criptografada" "$nome_usuario" >/dev/null 2>&1

# Salva senha e permissões
echo "$senha" | sudo tee "$senha_dir/$nome_usuario" >/dev/null
sudo chmod 777 "$senha_dir/$nome_usuario"

# Registra no DB
echo "$nome_usuario $limite_sessoes" | sudo tee -a "$db" >/dev/null

# Cria script de remoção agendada
conteudo_script="#!/bin/bash
sudo bash /opt/apipainel/RemoveUser.sh $nome_usuario >/dev/null 2>&1
sudo rm -f $caminho_scripts/$nome_usuario.sh >/dev/null 2>&1"

echo "$conteudo_script" | sudo tee "$caminho_scripts/$nome_usuario.sh" >/dev/null
sudo chmod 777 "$caminho_scripts/$nome_usuario.sh"

# Agenda remoção (silencioso)
sudo at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" min >/dev/null 2>&1

echo "sucesso"
