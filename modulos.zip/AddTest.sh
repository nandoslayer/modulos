#!/bin/bash

nome_usuario="$1"
senha="$2"
tempo_minutos="$3"
limite_sessoes="$4"

[ ! -f /root/usuarios.db ] && sudo touch /root/usuarios.db

sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

senha_criptografada=$(perl -e 'print crypt($ARGV[0], "password")' "$senha")

sudo useradd -M -s /bin/false -p "$senha_criptografada" -e "$(date -d "+$tempo_minutos minutes" +%Y-%m-%d)" "$nome_usuario" >/dev/null 2>&1

sudo mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" | sudo tee /etc/SSHPlus/senha/"$nome_usuario" >/dev/null

echo "$nome_usuario $limite_sessoes" | sudo tee -a /root/usuarios.db >/dev/null

caminho_scripts="/etc/TesteAtlas"
sudo mkdir -p "$caminho_scripts" >/dev/null 2>&1

cat <<EOF | sudo tee "$caminho_scripts/$nome_usuario.sh" >/dev/null
#!/bin/bash
sudo bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1
sudo rm -f "$caminho_scripts/$nome_usuario.sh"
EOF

sudo chmod +x "$caminho_scripts/$nome_usuario.sh"

sudo at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" minutes >/dev/null 2>&1

echo "sucesso"
