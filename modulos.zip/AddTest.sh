#!/bin/bash
nome_usuario="$1"
senha="$2"
tempo_minutos="$3"
limite_sessoes="$4"

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db
bash /opt/apipainel/RemoveUser.sh "$nome_usuario" &>/dev/null

data_expira=$(date -d "+2 days" +%Y-%m-%d)
senha_criptografada=$(openssl passwd -1 "$senha")

for uid in $(seq 1000 60000); do
  if ! getent passwd "$uid" &>/dev/null; then
    useradd -M -s /bin/false \
      -u "$uid" -p "$senha_criptografada" -e "$data_expira" \
      "$nome_usuario" &>/dev/null && break
  fi
done

if ! id "$nome_usuario" &>/dev/null; then
  useradd -M -s /bin/false \
    -p "$senha_criptografada" -e "$data_expira" \
    "$nome_usuario" &>/dev/null
fi

mkdir -p /etc/SSHPlus/senha/ &>/dev/null
echo "$senha" > "/etc/SSHPlus/senha/$nome_usuario"
echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

caminho_scripts="/etc/TesteAtlas"; mkdir -p "$caminho_scripts" &>/dev/null
cat <<EOF > "$caminho_scripts/$nome_usuario.sh"
#!/bin/bash
bash /opt/apipainel/RemoveUser.sh "$nome_usuario" &>/dev/null
rm -f "$caminho_scripts/$nome_usuario.sh"
EOF
chmod +x "$caminho_scripts/$nome_usuario.sh"

for job in $(atq | awk '{print $1}'); do
  at -c "$job" 2>/dev/null \
    | grep -q "$caminho_scripts/$nome_usuario.sh" \
    && atrm "$job"
done

at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" minutes &>/dev/null

echo "sucesso"
