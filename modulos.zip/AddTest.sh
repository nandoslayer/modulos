#!/bin/bash

nome_usuario="$1"
senha="$2"
tempo_minutos="$3"
limite_sessoes="$4"

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db

# Remove usuário antigo
bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

# Função para pegar o próximo UID livre (>=1000)
get_next_uid() {
    awk -F: '$3 >= 1000 { print $3 }' /etc/passwd | sort -n | awk 'END { print $1 + 1 }'
}

uid_livre=$(get_next_uid)

# Cria o usuário com UID livre e validade de 2 dias
senha_criptografada=$(openssl passwd -1 "$senha")
useradd -M -s /bin/false -u "$uid_livre" -p "$senha_criptografada" -e "$(date -d '+2 days' +%Y-%m-%d)" "$nome_usuario" >/dev/null 2>&1

# Salva senha
mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" > /etc/SSHPlus/senha/"$nome_usuario"

# Registra limite de sessões
echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

# Script de remoção futura
caminho_scripts="/etc/TesteAtlas"
mkdir -p "$caminho_scripts" >/dev/null 2>&1

cat <<EOF > "$caminho_scripts/$nome_usuario.sh"
#!/bin/bash
bash /opt/apipainel/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1
rm -f "$caminho_scripts/$nome_usuario.sh"
EOF

chmod +x "$caminho_scripts/$nome_usuario.sh"

# Remove agendamentos antigos do mesmo usuário
for job in $(atq | awk '{print $1}'); do
    at -c "$job" 2>/dev/null | grep -q "$caminho_scripts/$nome_usuario.sh" && atrm "$job"
done

# Agenda nova remoção
at -f "$caminho_scripts/$nome_usuario.sh" now + "$tempo_minutos" minutes >/dev/null 2>&1

echo "sucesso"
